<?php

include('conn.php');
include('mail.php');
include('UserMail.php');

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);

// For Keys count
$sql = "SELECT COUNT(*) as id_keys FROM keys_code";
$result = mysqli_query($conn, $sql);
$keycount = mysqli_fetch_assoc($result);

// For Active Keys count
$sql = "SELECT COUNT(devices) as devices FROM keys_code";
$result = mysqli_query($conn, $sql);
$active = mysqli_fetch_assoc($result);

// For In‑Active Keys Count
$sql = "SELECT COUNT(*) as devices FROM keys_code where devices IS NULL";
$result = mysqli_query($conn, $sql);
$inactive = mysqli_fetch_assoc($result);

// For Users Count
$sql = "SELECT COUNT(*) as id_users FROM users";
$result = mysqli_query($conn, $sql);
$users = mysqli_fetch_assoc($result);

$userid = session()->userid;
$sql = "SELECT `expiration_date` FROM `users` WHERE `id_users` = '".$userid."'";
$query = mysqli_query($conn, $sql);
$period = mysqli_fetch_assoc($query);

function HoursToDays($value)
{
    if ($value == 1) {
        return "{$value}س";
    } else if ($value >= 2 && $value < 24) {
        return "{$value}س";
    } else if ($value == 24) {
        $d = $value / 24;
        return "{$d} يوم";
    } else if ($value > 24) {
        $d = $value / 24;
        return "{$d} يوم";
    }
}

$dateTime    = strtotime($period['expiration_date']);
$getDateTime = date("F d, Y H:i:s", $dateTime);
$expFormatted = date("d/m/y H:i", $dateTime);
?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    /* ---- Custom Font ---- */
    @font-face {
        font-family: 'AR';
        src: url('/assets/fonts/ar_regular.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
        font-display: swap;
    }

    * { box-sizing: border-box; }

    body {
        font-family: 'AR', -apple-system, BlinkMacSystemFont, sans-serif;
        background: #080c14;
        color: #fff;
        -webkit-font-smoothing: antialiased;
    }

    /* ---- Page wrapper ---- */
    .dash-wrap {
        padding: 18px 14px 40px;
        max-width: 700px;
        margin: 0 auto;
    }

    /* ===========================
       HERO CARD  (Dashboard header)
    =========================== */
    .hero-card {
        background: linear-gradient(145deg, #0d1b2e 0%, #0a1628 60%, #0d1f35 100%);
        border: 1px solid rgba(0,229,255,0.14);
        border-radius: 20px;
        padding: 28px 22px 24px;
        text-align: center;
        position: relative;
        overflow: hidden;
        margin-bottom: 16px;
    }

    /* faint grid overlay */
    .hero-card::before {
        content: '';
        position: absolute;
        inset: 0;
        background-image:
            linear-gradient(rgba(0,229,255,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,229,255,0.04) 1px, transparent 1px);
        background-size: 28px 28px;
        pointer-events: none;
    }

    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: rgba(0,229,255,0.08);
        border: 1px solid rgba(0,229,255,0.25);
        color: #00e5ff;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 2.5px;
        padding: 5px 14px;
        border-radius: 50px;
        margin-bottom: 14px;
    }

    .hero-badge-dot {
        width: 6px; height: 6px;
        background: #00e5ff;
        border-radius: 50%;
        box-shadow: 0 0 8px #00e5ff;
        animation: blink 2s infinite;
    }

    @keyframes blink {
        0%,100%{opacity:1} 50%{opacity:0.25}
    }

    .hero-title {
        font-family: 'AR', sans-serif;
        font-size: 1.35rem;
        font-weight: 700;
        color: #fff;
        margin-bottom: 5px;
    }

    .hero-title span {
        color: #00e5ff;
    }

    .hero-sub {
        font-family: 'AR', sans-serif;
        font-size: 0.82rem;
        color: rgba(255,255,255,0.38);
        margin-bottom: 20px;
    }

    /* Avatar ring */
    .avatar-ring {
        width: 84px;
        height: 84px;
        border-radius: 50%;
        border: 2.5px solid #c9a227;
        padding: 4px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0,0,0,0.3);
        box-shadow: 0 0 20px rgba(201,162,39,0.25);
    }

    .avatar-ring img,
    .avatar-ring i {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
        font-size: 36px;
        color: #42a5f5;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .avatar-placeholder {
        width: 72px;
        height: 72px;
        border-radius: 50%;
        background: rgba(66,165,245,0.15);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 34px;
        color: #42a5f5;
    }

    /* ===========================
       INFO ROWS  (Balance / Level / Expiry)
    =========================== */
    .info-row {
        background: rgba(12,18,30,0.7);
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 16px;
        padding: 15px 18px;
        display: flex;
        align-items: center;
        gap: 16px;
        margin-bottom: 12px;
        position: relative;
        overflow: hidden;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .info-row:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0,0,0,0.35);
    }

    /* top accent line */
    .info-row::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 2px;
    }

    .info-row.accent-cyan::before  { background: linear-gradient(90deg,#00e5ff,transparent); }
    .info-row.accent-blue::before  { background: linear-gradient(90deg,#3b7dff,transparent); }
    .info-row.accent-amber::before { background: linear-gradient(90deg,#ffab00,transparent); }

    .info-icon-wrap {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 19px;
        flex-shrink: 0;
    }

    .icon-cyan  { background: rgba(0,229,255,0.12);  color: #00e5ff; }
    .icon-blue  { background: rgba(59,125,255,0.14); color: #5b9bff; }
    .icon-amber { background: rgba(255,171,0,0.13);  color: #ffab00; }

    .info-value {
        font-family: 'AR', sans-serif;
        font-size: 1.2rem;
        font-weight: 700;
        color: #fff;
        line-height: 1.2;
    }

    .info-label {
        font-family: 'AR', sans-serif;
        font-size: 0.78rem;
        color: rgba(255,255,255,0.38);
        margin-top: 2px;
    }

    /* ===========================
       STAT MINI CARDS  (4 top stats)
    =========================== */
    .stats-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-bottom: 14px;
    }

    .stat-mini {
        background: rgba(12,18,30,0.7);
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 16px;
        padding: 16px 16px 14px;
        position: relative;
        overflow: hidden;
        transition: transform 0.2s ease;
    }

    .stat-mini:hover { transform: translateY(-2px); }

    .stat-mini::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 2px;
    }

    .stat-mini.s-cyan::before  { background: linear-gradient(90deg,#00e5ff,transparent); }
    .stat-mini.s-green::before { background: linear-gradient(90deg,#00e676,transparent); }
    .stat-mini.s-red::before   { background: linear-gradient(90deg,#ff3b30,transparent); }
    .stat-mini.s-purple::before{ background: linear-gradient(90deg,#bf5af2,transparent); }

    .stat-mini-icon {
        width: 36px; height: 36px;
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        font-size: 16px;
        margin-bottom: 10px;
    }

    .si-cyan   { background: rgba(0,229,255,0.12);  color: #00e5ff; }
    .si-green  { background: rgba(0,230,118,0.12);  color: #00e676; }
    .si-red    { background: rgba(255,59,48,0.12);  color: #ff3b30; }
    .si-purple { background: rgba(191,90,242,0.12); color: #bf5af2; }

    .stat-mini-value {
        font-family: 'AR', sans-serif;
        font-size: 1.45rem;
        font-weight: 700;
        color: #fff;
        line-height: 1;
    }

    .stat-mini-label {
        font-family: 'AR', sans-serif;
        font-size: 0.74rem;
        color: rgba(255,255,255,0.38);
        margin-top: 4px;
    }

    .stat-trend {
        position: absolute;
        right: 12px; bottom: 12px;
        font-size: 10px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 20px;
        letter-spacing: 0.3px;
    }

    .trend-up   { background: rgba(0,230,118,0.12); color: #00e676; }
    .trend-down { background: rgba(255,59,48,0.12); color: #ff3b30; }

    /* ===========================
       HISTORY TABLE CARD
    =========================== */
    .history-card {
        background: rgba(12,18,30,0.7);
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 18px;
        overflow: hidden;
        margin-bottom: 14px;
    }

    .history-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 15px 18px 12px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
    }

    .history-head-left {
        font-family: 'AR', sans-serif;
        font-size: 0.9rem;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .history-head-left i { color: #00e5ff; font-size: 15px; }

    .btn-clear {
        font-family: 'AR', sans-serif;
        background: rgba(255,59,48,0.12);
        border: 1px solid rgba(255,59,48,0.3);
        color: #ff3b30;
        font-size: 12px;
        font-weight: 600;
        padding: 6px 14px;
        border-radius: 20px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
        text-decoration: none;
    }

    .btn-clear:hover {
        background: rgba(255,59,48,0.22);
        color: #ff3b30;
    }

    /* table */
    .vip-table {
        width: 100%;
        border-collapse: collapse;
    }

    .vip-table thead tr {
        border-bottom: 1px solid rgba(255,255,255,0.06);
    }

    .vip-table th {
        font-family: 'AR', sans-serif;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.5px;
        color: rgba(255,255,255,0.3);
        padding: 10px 18px;
        text-align: left;
    }

    .vip-table td {
        font-family: 'AR', sans-serif;
        font-size: 13px;
        color: rgba(255,255,255,0.75);
        padding: 11px 18px;
        border-bottom: 1px solid rgba(255,255,255,0.04);
    }

    .vip-table tbody tr:last-child td { border-bottom: none; }

    .vip-table tbody tr:hover td {
        background: rgba(0,229,255,0.04);
    }

    /* badges inside table */
    .tb-id {
        background: rgba(59,125,255,0.15);
        color: #5b9bff;
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 12px;
        font-weight: 600;
    }

    .tb-target {
        background: rgba(0,229,255,0.12);
        color: #00e5ff;
        border-radius: 6px;
        padding: 3px 9px;
        font-size: 12px;
        font-weight: 600;
    }

    .tb-key {
        background: rgba(191,90,242,0.12);
        color: #bf5af2;
        border-radius: 6px;
        padding: 3px 9px;
        font-size: 12px;
    }

    .tb-dur {
        background: rgba(255,171,0,0.12);
        color: #ffab00;
        border-radius: 6px;
        padding: 3px 9px;
        font-size: 12px;
        font-weight: 600;
    }

    /* ===========================
       COUNTDOWN  (inside expiry card)
    =========================== */
    #exp {
        font-family: 'AR', monospace;
        font-size: 1.05rem;
        color: #00e5ff;
        letter-spacing: 1px;
        text-shadow: 0 0 14px rgba(0,229,255,0.5);
    }

    /* mobile tweaks */
    @media (max-width: 480px) {
        .hero-title { font-size: 1.15rem; }
        .stat-mini-value { font-size: 1.2rem; }
        .vip-table th, .vip-table td { padding: 9px 12px; }
    }
</style>

<div class="dash-wrap">

    <div class="mb-3"><?= $this->include('Layout/msgStatus') ?></div>

    <div class="hero-card">
        <div class="hero-badge">
            <span class="hero-badge-dot"></span>
            لوحة التحكم
        </div>
        <div class="hero-title">
            أهلاً بعودتك، <span><?= esc($user->username ?? 'مستخدم') ?></span>
        </div>
        <div class="hero-sub">نظرة عامة على الحساب والنشاط الأخير</div>

        <div class="avatar-ring">
            <img src="/assets/img/avatar" alt="الصورة الشخصية">
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-mini s-cyan">
            <div class="stat-mini-icon si-cyan"><i class="bi bi-key-fill"></i></div>
            <div class="stat-mini-value"><?= $keycount['id_keys'] ?></div>
            <div class="stat-mini-label">إجمالي المفاتيح</div>
            <span class="stat-trend trend-up">+5.2%</span>
        </div>

        <div class="stat-mini s-green">
            <div class="stat-mini-icon si-green"><i class="bi bi-check-circle-fill"></i></div>
            <div class="stat-mini-value"><?= $active['devices'] ?></div>
            <div class="stat-mini-label">المفاتيح المستخدمة</div>
            <span class="stat-trend trend-up">+3.1%</span>
        </div>

        <div class="stat-mini s-red">
            <div class="stat-mini-icon si-red"><i class="bi bi-x-circle-fill"></i></div>
            <div class="stat-mini-value"><?= $inactive['devices'] ?></div>
            <div class="stat-mini-label">المفاتيح غير المستخدمة</div>
            <span class="stat-trend trend-down">-2.4%</span>
        </div>

        <div class="stat-mini s-purple">
            <div class="stat-mini-icon si-purple"><i class="bi bi-people-fill"></i></div>
            <div class="stat-mini-value"><?= $users['id_users'] ?></div>
            <div class="stat-mini-label">إجمالي المستخدمين</div>
            <span class="stat-trend trend-up">+7.8%</span>
        </div>
    </div>

    <div class="info-row accent-cyan">
        <div class="info-icon-wrap icon-cyan">
            <i class="bi bi-wallet2"></i>
        </div>
        <div>
            <div class="info-value">₹<?= number_format($user->saldo ?? 0) ?></div>
            <div class="info-label">رصيد الحساب</div>
        </div>
    </div>

    <div class="info-row accent-blue">
        <div class="info-icon-wrap icon-blue">
            <i class="bi bi-shield-fill-check"></i>
        </div>
        <div>
            <div class="info-value"><?= getLevel($user->level) ?></div>
            <div class="info-label">اسم الحساب</div>
        </div>
    </div>

    <div class="info-row accent-amber">
        <div class="info-icon-wrap icon-amber">
            <i class="bi bi-calendar3"></i>
        </div>
        <div>
            <div class="info-value" id="exp"><?= $expFormatted ?></div>
            <div class="info-label">انتهاء صلاحية اللوحة</div>
        </div>
    </div>

    <div class="history-card">
        <div class="history-head">
            <div class="history-head-left">
                <i class="bi bi-clock-history"></i>
                سجل التسجيل
            </div>
            <?php if ($user->level == 1) : ?>
            <a href="javascript:void(0)" onclick="clearLogs()" class="btn-clear">
                <i class="bi bi-trash3-fill"></i> مسح
            </a>
            <?php endif; ?>
        </div>

        <div class="table-responsive">
            <table class="vip-table">
                <thead>
                    <tr>
                        <th>المعرف</th>
                        <th>المستهدف</th>
                        <th>المفتاح</th>
                        <th>المدة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $h) : ?>
                        <?php $in = explode("|", $h->info); ?>
                        <tr>
                            <td><span class="tb-id">#3812<?= $h->id_history ?></span></td>
                            <td><span class="tb-target"><?= esc($in[0]) ?></span></td>
                            <td><span class="tb-key"><?= esc($in[1]) ?>**</span></td>
                            <td><span class="tb-dur"><?= HoursToDays($in[2]) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
    // Countdown timer
    var countDownTimer = new Date("<?= $getDateTime ?>").getTime();
    var interval = setInterval(function () {
        var now  = new Date().getTime();
        var diff = countDownTimer - now;

        if (diff < 0) {
            clearInterval(interval);
            document.getElementById("exp").innerHTML = "منتهي الصلاحية";
            return;
        }

        var days    = Math.floor(diff / (1000 * 60 * 60 * 24));
        var hours   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((diff % (1000 * 60)) / 1000);

        // تنسيق مخصص للوقت ليظهر بشكل مرتب
        document.getElementById("exp").innerHTML = 
            (days > 0 ? days + " يوم " : "") + 
            hours + " س " + 
            minutes + " د " + 
            seconds + " ث";
    }, 1000);

    // Clear Logs function
    function clearLogs() {
        Swal.fire({
            title: 'هل أنت متأكد؟',
            text: "سيتم حذف جميع السجلات نهائياً!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'نعم، حذف',
            cancelButtonText: 'إلغاء'
        }).then((result) => {
            if (result.isConfirmed) {
                $.get("<?= site_url('admin/clearLogs') ?>", function() {
                    location.reload();
                });
            }
        });
    }
</script>


<?= $this->endSection() ?>
