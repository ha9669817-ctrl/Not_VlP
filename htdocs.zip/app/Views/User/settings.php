<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="settings-wrap">

    <!-- msgStatus -->
    <?= $this->include('Layout/msgStatus') ?>

    <!-- Page Title -->
    <div class="page-hero mb-4">
        <div class="page-badge">
            <span class="badge-dot"></span>
            الإعدادات
        </div>
        <h2 class="page-title">إعدادات الحساب</h2>
        <p class="page-sub">إدارة كلمة المرور ومعلومات الملف الشخصي</p>
    </div>

    <div class="row g-4">

        <!-- ── Change Password ─────────────────── -->
        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header accent-cyan">
                    <div class="header-left">
                        <div class="header-icon icon-cyan">
                            <i class="bi bi-shield-lock-fill"></i>
                        </div>
                        <span>تغيير كلمة المرور</span>
                    </div>
                </div>

                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="password_form" value="1">

                    <!-- Current Password -->
                    <div class="field-group mb-4">
                        <label class="field-label">
                            <i class="bi bi-lock-fill me-1"></i> كلمة المرور الحالية
                        </label>
                        <div class="input-wrapper">
                            <span class="input-icon"><i class="bi bi-key"></i></span>
                            <input type="password"
                                   name="current" id="current"
                                   class="vip-input <?= $validation->hasError('current') ? 'is-invalid' : '' ?>"
                                   placeholder="أدخل كلمة المرور الحالية"
                                   autocomplete="current-password">
                            <button type="button" class="eye-btn" onclick="togglePass('current', this)">
                                <i class="bi bi-eye-fill"></i>
                            </button>
                        </div>
                        <?php if ($validation->hasError('current')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('current') ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- New Password -->
                    <div class="field-group mb-4">
                        <label class="field-label">
                            <i class="bi bi-shield-fill-check me-1"></i> كلمة المرور الجديدة
                        </label>
                        <div class="input-wrapper">
                            <span class="input-icon"><i class="bi bi-key-fill"></i></span>
                            <input type="password"
                                   name="password" id="password"
                                   class="vip-input <?= $validation->hasError('password') ? 'is-invalid' : '' ?>"
                                   placeholder="أدخل كلمة المرور الجديدة"
                                   autocomplete="new-password">
                            <button type="button" class="eye-btn" onclick="togglePass('password', this)">
                                <i class="bi bi-eye-fill"></i>
                            </button>
                        </div>
                        <?php if ($validation->hasError('password')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('password') ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- Confirm Password -->
                    <div class="field-group mb-5">
                        <label class="field-label">
                            <i class="bi bi-shield-check me-1"></i> تأكيد كلمة المرور
                        </label>
                        <div class="input-wrapper">
                            <span class="input-icon"><i class="bi bi-key-fill"></i></span>
                            <input type="password"
                                   name="password2" id="password2"
                                   class="vip-input <?= $validation->hasError('password2') ? 'is-invalid' : '' ?>"
                                   placeholder="تأكيد كلمة المرور الجديدة"
                                   autocomplete="new-password">
                            <button type="button" class="eye-btn" onclick="togglePass('password2', this)">
                                <i class="bi bi-eye-fill"></i>
                            </button>
                        </div>
                        <?php if ($validation->hasError('password2')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('password2') ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="vip-btn btn-cyan">
                        <i class="bi bi-shield-lock me-2"></i> تغيير كلمة المرور
                    </button>

                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <!-- ── Account Information ─────────────── -->
        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header accent-purple">
                    <div class="header-left">
                        <div class="header-icon icon-purple">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <span>معلومات الحساب</span>
                    </div>
                </div>

                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="fullname_form" value="1">

                    <!-- Account username (readonly) -->
                    <div class="field-group mb-4">
                        <label class="field-label">
                            <i class="bi bi-person-badge me-1"></i> اسم المستخدم
                        </label>
                        <div class="input-wrapper">
                            <span class="input-icon"><i class="bi bi-at"></i></span>
                            <input type="text"
                                   class="vip-input"
                                   value="<?= esc($user->username ?? '') ?>"
                                   readonly
                                   style="opacity:0.5; cursor:not-allowed;">
                        </div>
                    </div>

                    <!-- Full Name -->
                    <div class="field-group mb-5">
                        <label class="field-label">
                            <i class="bi bi-card-text me-1"></i> الاسم الكامل
                        </label>
                        <div class="input-wrapper">
                            <span class="input-icon"><i class="bi bi-person-vcard"></i></span>
                            <input type="text"
                                   name="fullname" id="fullname"
                                   class="vip-input <?= $validation->hasError('fullname') ? 'is-invalid' : '' ?>"
                                   placeholder="أدخل اسمك الكامل"
                                   value="<?= old('fullname') ?: esc($user->fullname ?? '') ?>">
                        </div>
                        <?php if ($validation->hasError('fullname')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('fullname') ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="vip-btn btn-purple">
                        <i class="bi bi-check-circle me-2"></i> تحديث الحساب
                    </button>

                    <?= form_close() ?>
                </div>
            </div>

            <!-- Account Info Panel (read-only stats) -->
            <div class="vip-info-panel mt-4">
                <div class="info-panel-row">
                    <span class="info-panel-label"><i class="bi bi-shield-fill me-2" style="color:#00e5ff;"></i>المستوى</span>
                    <span class="info-panel-value"><?= getLevel($user->level ?? 3) ?></span>
                </div>
                <div class="info-panel-row">
                    <span class="info-panel-label"><i class="bi bi-wallet2 me-2" style="color:#00e676;"></i>الرصيد</span>
                    <span class="info-panel-value" style="color:#00e676;">₹<?= number_format($user->saldo ?? 0) ?></span>
                </div>
                <div class="info-panel-row">
                    <span class="info-panel-label"><i class="bi bi-calendar3 me-2" style="color:#ffab00;"></i>تاريخ الانتهاء</span>
                    <span class="info-panel-value" style="color:#ffab00;"><?= $user->expiration_date ?? '-' ?></span>
                </div>
            </div>

        </div>
    </div>

</div>

<!-- STYLES -->
<style>
@font-face {
    font-family: 'AR';
    src: url('/assets/fonts/ar_regular.ttf') format('truetype');
    font-display: swap;
}

.settings-wrap {
    padding: 20px 4px 60px;
    font-family: 'AR', -apple-system, sans-serif;
}

/* Page Hero */
.page-hero {
    text-align: center;
    padding: 10px 0 4px;
}

.page-badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: rgba(0,229,255,0.08);
    border: 1px solid rgba(0,229,255,0.25);
    color: #00e5ff;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 2.5px;
    padding: 5px 14px;
    border-radius: 50px;
    margin-bottom: 12px;
    font-family: 'AR', sans-serif;
}

.badge-dot {
    width: 6px; height: 6px;
    background: #00e5ff;
    border-radius: 50%;
    box-shadow: 0 0 8px #00e5ff;
    animation: blink 2s infinite;
}

@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.25} }

.page-title {
    font-family: 'AR', sans-serif;
    font-size: 1.6rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 5px;
}

.page-sub {
    font-family: 'AR', sans-serif;
    font-size: 0.85rem;
    color: rgba(255,255,255,0.35);
    margin: 0;
}

/* Card */
.vip-card {
    background: rgba(12,18,30,0.7);
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 18px;
    overflow: hidden;
    transition: transform 0.25s ease, box-shadow 0.25s ease;
}

.vip-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 36px rgba(0,0,0,0.45);
}

/* Card Header */
.vip-card-header {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.06);
    position: relative;
}

.vip-card-header::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
}

.accent-cyan::before   { background: linear-gradient(90deg, #00e5ff, transparent); }
.accent-purple::before { background: linear-gradient(90deg, #bf5af2, transparent); }

.header-left {
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: 'AR', sans-serif;
    font-size: 0.95rem;
    font-weight: 700;
    color: #fff;
}

.header-icon {
    width: 34px; height: 34px;
    border-radius: 9px;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px;
}

.icon-cyan   { background: rgba(0,229,255,0.12);  color: #00e5ff; }
.icon-purple { background: rgba(191,90,242,0.12); color: #bf5af2; }

/* Card Body */
.vip-card-body { padding: 24px 22px 22px; }

/* Labels */
.field-label {
    font-family: 'AR', sans-serif;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.5px;
    color: rgba(255,255,255,0.4);
    margin-bottom: 8px;
    display: block;
}

/* Input */
.input-wrapper { position: relative; }

.input-icon {
    position: absolute;
    left: 14px; top: 50%;
    transform: translateY(-50%);
    color: rgba(255,255,255,0.28);
    font-size: 15px;
    pointer-events: none;
    z-index: 2;
    transition: color 0.2s;
}

.input-wrapper:focus-within .input-icon { color: #00e5ff; }

.vip-input {
    font-family: 'AR', sans-serif;
    width: 100%;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.09);
    border-radius: 12px;
    color: #fff;
    font-size: 0.92rem;
    padding: 13px 44px 13px 42px;
    outline: none;
    transition: all 0.25s ease;
    -webkit-appearance: none;
}

.vip-input::placeholder { color: rgba(255,255,255,0.22); }

.vip-input:focus {
    background: rgba(0,229,255,0.06);
    border-color: rgba(0,229,255,0.42);
    box-shadow: 0 0 0 3px rgba(0,229,255,0.09);
}

.vip-input.is-invalid { border-color: rgba(255,59,48,0.55); }

.vip-invalid {
    font-family: 'AR', sans-serif;
    font-size: 11.5px;
    color: #ff6b60;
    margin-top: 6px;
    padding-left: 4px;
}

/* Eye Button */
.eye-btn {
    position: absolute;
    right: 13px; top: 50%;
    transform: translateY(-50%);
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.28);
    font-size: 15px;
    padding: 0;
    cursor: pointer;
    z-index: 3;
    transition: color 0.2s;
    -webkit-appearance: none;
}
.eye-btn:hover { color: #00e5ff; }

/* Buttons */
.vip-btn {
    font-family: 'AR', sans-serif;
    width: 100%;
    border: none;
    border-radius: 12px;
    font-size: 0.9rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    padding: 13px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    -webkit-appearance: none;
}

.vip-btn:hover { transform: translateY(-2px); }

.btn-cyan {
    background: linear-gradient(135deg, #00c8e0, #00e5ff);
    color: #000;
    box-shadow: 0 4px 16px rgba(0,229,255,0.2);
}
.btn-cyan:hover { box-shadow: 0 8px 26px rgba(0,229,255,0.4); }

.btn-purple {
    background: linear-gradient(135deg, #a040e0, #bf5af2);
    color: #fff;
    box-shadow: 0 4px 16px rgba(191,90,242,0.2);
}
.btn-purple:hover { box-shadow: 0 8px 26px rgba(191,90,242,0.4); }

/* Shine animation */
.vip-btn::after {
    content: '';
    position: absolute;
    top: -50%; left: -60%;
    width: 40%; height: 200%;
    background: rgba(255,255,255,0.2);
    transform: skewX(-20deg);
    animation: shine 3.5s infinite;
}
@keyframes shine { 0%{left:-60%} 100%{left:160%} }

/* Info Panel */
.vip-info-panel {
    background: rgba(12,18,30,0.7);
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 16px;
    overflow: hidden;
}

.info-panel-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 13px 18px;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}
.info-panel-row:last-child { border-bottom: none; }

.info-panel-label {
    font-family: 'AR', sans-serif;
    font-size: 0.83rem;
    color: rgba(255,255,255,0.4);
    display: flex;
    align-items: center;
}

.info-panel-value {
    font-family: 'AR', sans-serif;
    font-size: 0.88rem;
    font-weight: 600;
    color: rgba(255,255,255,0.75);
}

/* iOS */
@supports (-webkit-touch-callout: none) {
    .vip-input, .vip-btn { -webkit-appearance: none; border-radius: 12px; }
}
</style>

<!-- SCRIPT -->
<script>
function togglePass(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('bi-eye-fill', 'bi-eye-slash-fill');
    } else {
        input.type = 'password';
        icon.classList.replace('bi-eye-slash-fill', 'bi-eye-fill');
    }
}
</script>

<?= $this->endSection() ?>
