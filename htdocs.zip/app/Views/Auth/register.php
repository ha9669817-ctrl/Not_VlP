<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="reg-wrapper d-flex justify-content-center align-items-center">
    <div class="col-lg-4 col-md-6 col-sm-10 col-11">
        <?= $this->include('Layout/msgStatus') ?>

        <div class="reg-card">

            <div class="reg-header">
                <div class="reg-badge">
                    <span class="reg-badge-dot"></span>
                    حساب جديد
                </div>
                <h3 class="reg-title">إنشاء حساب</h3>
                <p class="reg-subtitle">املأ البيانات أدناه</p>
            </div>

            <div class="reg-divider"></div>

            <div class="reg-body">
                <?= form_open() ?>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-person-fill me-1"></i> اسم المستخدم
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-at"></i></span>
                        <input type="text"
                               class="vip-input <?= $validation->hasError('username') ? 'is-invalid' : '' ?>"
                               name="username"
                               id="username"
                               placeholder="اختر اسم مستخدم"
                               minlength="4" maxlength="24"
                               value="<?= old('username') ?>"
                               required
                               autocomplete="username">
                        <?php if ($validation->hasError('username')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('username') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-card-text me-1"></i> الاسم الكامل
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-person-vcard"></i></span>
                        <input type="text"
                               class="vip-input <?= $validation->hasError('fullname') ? 'is-invalid' : '' ?>"
                               name="fullname"
                               id="fullname"
                               placeholder="أدخل اسمك الكامل"
                               minlength="4" maxlength="24"
                               value="<?= old('fullname') ?>"
                               required>
                        <?php if ($validation->hasError('fullname')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('fullname') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-shield-lock-fill me-1"></i> كلمة المرور
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-key"></i></span>
                        <input type="password"
                               class="vip-input <?= $validation->hasError('password') ? 'is-invalid' : '' ?>"
                               name="password"
                               id="password"
                               placeholder="أنشئ كلمة مرور"
                               minlength="6" maxlength="24"
                               required
                               autocomplete="new-password">
                        <button type="button" class="eye-btn" onclick="togglePassword('password', this)" tabindex="-1">
                            <i class="bi bi-eye-fill"></i>
                        </button>
                        <?php if ($validation->hasError('password')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('password') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-shield-fill-check me-1"></i> تأكيد كلمة المرور
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-key-fill"></i></span>
                        <input type="password"
                               class="vip-input <?= $validation->hasError('password2') ? 'is-invalid' : '' ?>"
                               name="password2"
                               id="password2"
                               placeholder="أكد كلمة المرور الخاصة بك"
                               minlength="6" maxlength="24"
                               required
                               autocomplete="new-password">
                        <button type="button" class="eye-btn" onclick="togglePassword('password2', this)" tabindex="-1">
                            <i class="bi bi-eye-fill"></i>
                        </button>
                        <?php if ($validation->hasError('password2')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('password2') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="field-group mb-5">
                    <label class="field-label">
                        <i class="bi bi-tag-fill me-1"></i> كود الإحالة
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-upc-scan"></i></span>
                        <input type="text"
                               class="vip-input <?= $validation->hasError('referral') ? 'is-invalid' : '' ?>"
                               name="referral"
                               id="referral"
                               placeholder="أدخل كود الإحالة"
                               maxlength="25"
                               value="<?= old('referral') ?>"
                               required>
                        <?php if ($validation->hasError('referral')) : ?>
                            <div class="vip-invalid"><?= $validation->getError('referral') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="d-grid mb-2">
                    <button type="submit" class="btn-create">
                        <i class="bi bi-person-plus-fill me-2"></i> إنشاء حساب
                    </button>
                </div>

                <?= form_close() ?>

                <div class="or-divider"><span>أو</span></div>

                <div class="text-center mt-3">
                    <p class="login-text">
                        هل لديك حساب بالفعل؟
                        <a href="<?= site_url('login') ?>" class="vip-link">تسجيل الدخول</a>
                    </p>
                </div>
            </div>
            </div>
        </div>
</div>

<style>

    /* ---- Wrapper ---- */
    .reg-wrapper {
        min-height: 90vh;
        padding: 30px 0;
    }

    /* =====================
       CARD
    ===================== */
    .reg-card {
        background: rgba(15, 20, 30, 0.75);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(0, 229, 255, 0.18);
        border-radius: 20px;
        overflow: hidden;
        box-shadow:
            0 0 0 1px rgba(0,229,255,0.05),
            0 20px 60px rgba(0,0,0,0.6),
            inset 0 1px 0 rgba(255,255,255,0.04);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .reg-card:hover {
        transform: translateY(-4px);
        box-shadow:
            0 0 0 1px rgba(0,229,255,0.12),
            0 28px 70px rgba(0,0,0,0.7),
            0 0 40px rgba(0,229,255,0.06);
    }

    /* =====================
       HEADER
    ===================== */
    .reg-header {
        padding: 32px 32px 22px;
        text-align: center;
        background: linear-gradient(160deg, rgba(0,229,255,0.06) 0%, transparent 60%);
    }

    .reg-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: rgba(0,229,255,0.1);
        border: 1px solid rgba(0,229,255,0.3);
        color: #00e5ff;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 2px;
        padding: 5px 14px;
        border-radius: 50px;
        margin-bottom: 16px;
        font-family: 'AR', sans-serif;
    }

    .reg-badge-dot {
        width: 6px; height: 6px;
        background: #00e5ff;
        border-radius: 50%;
        box-shadow: 0 0 8px #00e5ff;
        animation: blink 2s infinite;
        flex-shrink: 0;
    }

    @keyframes blink {
        0%,100% { opacity: 1; }
        50%      { opacity: 0.25; }
    }

    .reg-title {
        font-family: 'AR', sans-serif;
        font-size: 1.75rem;
        font-weight: 700;
        color: #ffffff;
        margin-bottom: 6px;
        letter-spacing: 0.3px;
    }

    .reg-subtitle {
        font-family: 'AR', sans-serif;
        font-size: 0.87rem;
        color: rgba(255,255,255,0.4);
        margin: 0;
    }

    .reg-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(0,229,255,0.22), transparent);
        margin: 0 24px;
    }

    /* =====================
       BODY
    ===================== */
    .reg-body {
        padding: 26px 32px 32px;
    }

    /* ---- Labels ---- */
    .field-label {
        font-family: 'AR', sans-serif;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1.5px;
        color: rgba(255,255,255,0.45);
        margin-bottom: 8px;
        display: block;
    }

    /* ---- Inputs ---- */
    .input-wrapper {
        position: relative;
    }

    .input-icon {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: rgba(255,255,255,0.28);
        font-size: 15px;
        pointer-events: none;
        z-index: 2;
        transition: color 0.2s;
    }

    .input-wrapper:focus-within .input-icon {
        color: #00e5ff;
    }

    .vip-input {
        font-family: 'AR', sans-serif;
        width: 100%;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.09);
        border-radius: 12px;
        color: #fff;
        font-size: 0.92rem;
        padding: 13px 44px 13px 42px;
        outline: none;
        transition: all 0.25s ease;
        -webkit-appearance: none;
    }

    .vip-input::placeholder {
        color: rgba(255,255,255,0.22);
    }

    .vip-input:focus {
        background: rgba(0,229,255,0.06);
        border-color: rgba(0,229,255,0.42);
        box-shadow: 0 0 0 3px rgba(0,229,255,0.09);
        color: #fff;
    }

    .vip-input.is-invalid {
        border-color: rgba(255,59,48,0.55);
    }

    .vip-invalid {
        font-family: 'AR', sans-serif;
        font-size: 11.5px;
        color: #ff6b60;
        margin-top: 6px;
        padding-left: 4px;
    }

    /* ---- Eye toggle ---- */
    .eye-btn {
        position: absolute;
        right: 13px;
        top: 50%;
        transform: translateY(-50%);
        background: transparent;
        border: none;
        color: rgba(255,255,255,0.28);
        font-size: 15px;
        padding: 0;
        cursor: pointer;
        z-index: 3;
        transition: color 0.2s;
        -webkit-appearance: none;
    }

    .eye-btn:hover { color: #00e5ff; }

    /* =====================
       CREATE ACCOUNT BUTTON
    ===================== */
    .btn-create {
        font-family: 'AR', sans-serif;
        width: 100%;
        background: linear-gradient(135deg, #00c8e0, #00e5ff);
        border: none;
        border-radius: 12px;
        color: #000;
        font-size: 0.94rem;
        font-weight: 700;
        letter-spacing: 1.8px;
        padding: 14px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
        -webkit-appearance: none;
    }

    .btn-create:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 26px rgba(0,229,255,0.4);
    }

    .btn-create:active { transform: translateY(0); }

    .btn-create::after {
        content: '';
        position: absolute;
        top: -50%;
        left: -60%;
        width: 40%;
        height: 200%;
        background: rgba(255,255,255,0.25);
        transform: skewX(-20deg);
        animation: shine-btn 3.5s infinite;
    }

    @keyframes shine-btn {
        0%   { left: -60%; }
        100% { left: 160%; }
    }

    /* ---- OR divider ---- */
    .or-divider {
        display: flex;
        align-items: center;
        gap: 12px;
        color: rgba(255,255,255,0.18);
        font-size: 11px;
        letter-spacing: 2px;
        font-family: 'AR', sans-serif;
        margin: 20px 0 0;
    }

    .or-divider::before,
    .or-divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: rgba(255,255,255,0.08);
    }

    /* ---- Login link ---- */
    .login-text {
        font-family: 'AR', sans-serif;
        font-size: 0.87rem;
        color: rgba(255,255,255,0.32);
        margin: 0;
    }

    .vip-link {
        color: #00e5ff;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.2s;
    }

    .vip-link:hover {
        color: #fff;
        text-shadow: 0 0 12px rgba(0,229,255,0.8);
    }

    /* ---- iOS fixes ---- */
    @supports (-webkit-touch-callout: none) {
        .vip-input, .btn-create {
            -webkit-appearance: none;
            border-radius: 12px;
        }
    }
</style>

<script>
function togglePassword(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('bi-eye-fill', 'bi-eye-slash-fill');
    } else {
        input.type = 'password';
        icon.classList.replace('bi-eye-slash-fill', 'bi-eye-fill');
    }
}
</script>

<?= $this->endSection() ?>
