<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div id="particles-js" class="animated-bg"></div>

<div class="login-wrapper d-flex justify-content-center align-items-center">
    <div class="col-lg-4 col-md-6 col-sm-10 col-11">
        <?= $this->include('Layout/msgStatus') ?>

        <div class="login-card">
            <div class="login-header">
                <div class="secure-badge">
                    <span class="badge-dot"></span>
                    دخول آمن
                </div>
                <h3 class="login-title">أهلاً بعودتك</h3>
                <p class="login-subtitle">سجل الدخول إلى حسابك</p>
            </div>

            <div class="login-divider"></div>

            <div class="login-body">
                <?= form_open() ?>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-person-fill me-1"></i> اسم المستخدم
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-at"></i></span>
                        <input type="text"
                               class="vip-input <?= $validation->hasError('username') ? 'is-invalid' : '' ?>"
                               name="username"
                               id="username"
                               placeholder="أدخل اسم المستخدم"
                               value="<?= old('username') ?>"
                               required
                               minlength="4"
                               autocomplete="username">
                        <?php if ($validation->hasError('username')) : ?>
                            <div class="invalid-feedback"><?= $validation->getError('username') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="field-group mb-4">
                    <label class="field-label">
                        <i class="bi bi-shield-lock-fill me-1"></i> كلمة المرور
                    </label>
                    <div class="input-wrapper">
                        <span class="input-icon"><i class="bi bi-key"></i></span>
                        <input type="password"
                               class="vip-input <?= $validation->hasError('password') ? 'is-invalid' : '' ?>"
                               name="password"
                               id="password"
                               placeholder="أدخل كلمة المرور"
                               required
                               minlength="6"
                               autocomplete="current-password">
                        <?php if ($validation->hasError('password')) : ?>
                            <div class="invalid-feedback"><?= $validation->getError('password') ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <input type="hidden" name="user_agent" value="<?= esc($_SERVER['HTTP_USER_AGENT']) ?>">

                <div class="remember-row mb-4">
                    <label class="vip-checkbox-label">
                        <input type="checkbox" class="vip-checkbox" name="stay_log" id="stay_log" value="yes">
                        <span class="checkmark"></span>
                        تذكرني
                    </label>
                </div>

                <div class="d-grid mb-2">
                    <button type="submit" class="btn-signin">
                        <i class="bi bi-box-arrow-in-right me-2"></i> تسجيل الدخول
                    </button>
                </div>

                <?= form_close() ?>

                <div class="or-divider"><span>أو</span></div>

                <div class="text-center mt-3">
                    <p class="register-text">
                        لا تملك حساباً؟
                        <a href="<?= site_url('register') ?>" class="vip-link">إنشاء حساب</a>
                    </p>
                </div>
            </div>
        </div>
        </div>
</div>


<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<script>
particlesJS('particles-js', {
    particles: {
        number: { value: 60, density: { enable: true, value_area: 800 } },
        color: { value: "#00e5ff" },
        shape: { type: "circle" },
        opacity: { value: 0.25 },
        size: { value: 2.5, random: true },
        line_linked: {
            enable: true,
            distance: 140,
            color: "#00e5ff",
            opacity: 0.15,
            width: 1
        },
        move: {
            enable: true,
            speed: 2.5,
            direction: "none",
            out_mode: "out"
        }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: { enable: true, mode: "repulse" },
            onclick: { enable: true, mode: "push" },
            resize: true
        }
    },
    retina_detect: true
});
</script>

<!-- Login Page Styles -->
<style>
/* ===== LOGIN WRAPPER ===== */
.login-wrapper {
    min-height: 90vh;
    padding: 30px 0;
}

/* ===== LOGIN CARD ===== */
.login-card {
    background: rgba(15, 20, 30, 0.75);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(0, 229, 255, 0.18);
    border-radius: 20px;
    overflow: hidden;
    box-shadow:
        0 0 0 1px rgba(0,229,255,0.05),
        0 20px 60px rgba(0,0,0,0.6),
        inset 0 1px 0 rgba(255,255,255,0.04);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.login-card:hover {
    transform: translateY(-4px);
    box-shadow:
        0 0 0 1px rgba(0,229,255,0.12),
        0 28px 70px rgba(0,0,0,0.7),
        0 0 40px rgba(0,229,255,0.06);
}

/* ===== CARD HEADER ===== */
.login-header {
    padding: 32px 32px 24px;
    text-align: center;
    background: linear-gradient(160deg, rgba(0,229,255,0.06) 0%, transparent 60%);
}

.secure-badge {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: rgba(0,229,255,0.1);
    border: 1px solid rgba(0,229,255,0.3);
    color: #00e5ff;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 2px;
    padding: 5px 14px;
    border-radius: 50px;
    margin-bottom: 18px;
}

.badge-dot {
    width: 6px;
    height: 6px;
    background: #00e5ff;
    border-radius: 50%;
    box-shadow: 0 0 8px #00e5ff;
    animation: pulse-dot 2s infinite;
}

@keyframes pulse-dot {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}

.login-title {
    font-family: 'AR', sans-serif;
    font-size: 1.8rem;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 6px;
    letter-spacing: 0.5px;
}

.login-subtitle {
    font-family: 'AR', sans-serif;
    font-size: 0.88rem;
    color: rgba(255,255,255,0.45);
    margin: 0;
}

.login-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0,229,255,0.25), transparent);
    margin: 0 24px;
}

/* ===== CARD BODY ===== */
.login-body {
    padding: 28px 32px 32px;
}

/* ===== FIELD LABELS ===== */
.field-label {
    font-family: 'AR', sans-serif;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.5px;
    color: rgba(255,255,255,0.5);
    margin-bottom: 8px;
    display: block;
}

/* ===== INPUT FIELDS ===== */
.input-wrapper {
    position: relative;
}

.input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255,255,255,0.3);
    font-size: 15px;
    pointer-events: none;
    z-index: 2;
    transition: color 0.2s;
}

.vip-input {
    font-family: 'AR', sans-serif;
    width: 100%;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    color: #fff;
    font-size: 0.93rem;
    padding: 13px 16px 13px 42px;
    outline: none;
    transition: all 0.25s ease;
    -webkit-appearance: none;
}

.vip-input::placeholder {
    color: rgba(255,255,255,0.25);
}

.vip-input:focus {
    background: rgba(0,229,255,0.06);
    border-color: rgba(0,229,255,0.45);
    box-shadow: 0 0 0 3px rgba(0,229,255,0.1);
    color: #fff;
}

.vip-input:focus + .input-icon,
.input-wrapper:focus-within .input-icon {
    color: #00e5ff;
}

.vip-input.is-invalid {
    border-color: rgba(255,80,80,0.6);
}

/* ===== REMEMBER ME ===== */
.remember-row {
    display: flex;
    align-items: center;
}

.vip-checkbox-label {
    font-family: 'AR', sans-serif;
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    color: rgba(255,255,255,0.6);
    font-size: 0.88rem;
    user-select: none;
}

.vip-checkbox {
    display: none;
}

.checkmark {
    width: 18px;
    height: 18px;
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 4px;
    background: rgba(255,255,255,0.05);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    flex-shrink: 0;
}

.vip-checkbox:checked ~ .checkmark {
    background: #00e5ff;
    border-color: #00e5ff;
    box-shadow: 0 0 10px rgba(0,229,255,0.4);
}

.vip-checkbox:checked ~ .checkmark::after {
    content: '✓';
    color: #000;
    font-size: 11px;
    font-weight: 900;
}

/* ===== SIGN IN BUTTON ===== */
.btn-signin {
    font-family: 'AR', sans-serif;
    width: 100%;
    background: linear-gradient(135deg, #00c8e0, #00e5ff);
    border: none;
    border-radius: 12px;
    color: #000;
    font-size: 0.95rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    padding: 14px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    -webkit-appearance: none;
}

.btn-signin:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,229,255,0.4);
}

.btn-signin:active {
    transform: translateY(0);
}

.btn-signin::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -60%;
    width: 40%;
    height: 200%;
    background: rgba(255,255,255,0.25);
    transform: skewX(-20deg);
    animation: shine-btn 3.5s infinite;
}

@keyframes shine-btn {
    0% { left: -60%; }
    100% { left: 160%; }
}

/* ===== OR DIVIDER ===== */
.or-divider {
    display: flex;
    align-items: center;
    gap: 12px;
    color: rgba(255,255,255,0.2);
    font-size: 12px;
    letter-spacing: 2px;
    margin: 20px 0 0;
}

.or-divider::before,
.or-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(255,255,255,0.1);
}

/* ===== REGISTER LINK ===== */
.register-text {
    font-family: 'AR', sans-serif;
    font-size: 0.88rem;
    color: rgba(255,255,255,0.35);
    margin: 0;
}

.vip-link {
    color: #00e5ff;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.2s;
}

.vip-link:hover {
    color: #fff;
    text-shadow: 0 0 12px rgba(0,229,255,0.8);
}

/* ===== iOS STYLE FIXES ===== */
@supports (-webkit-touch-callout: none) {
    .vip-input,
    .btn-signin {
        -webkit-appearance: none;
        border-radius: 12px;
    }
}
</style>

<?= $this->endSection() ?>
