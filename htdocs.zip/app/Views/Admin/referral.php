<?php
include('conn.php');
include('mail.php');

// For Highest id Ref
$sqli = "SELECT * FROM referral_code ORDER BY id_reff DESC LIMIT 1;";
$result = mysqli_query($conn, $sqli);
$id_reff = mysqli_fetch_assoc($result);

// For Referral Code
$sql = "SELECT Referral FROM referral_code";
$result = mysqli_query($conn, $sql);
$refcode = mysqli_fetch_assoc($result);
$row = $refcode;
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
/* ══════════════════════════════════════
   AR TECHNI FONT
══════════════════════════════════════ */
@font-face {
    font-family: 'AR Techni';
    src: url('<?= base_url('assets/fonts/AR_Techni.ttf') ?>') format('truetype');
    font-weight: normal;
    font-style: normal;
}

html, body,
*,
*::before,
*::after,
input, select, textarea, button,
label, th, td, span, div, p, a,
.vip-label, .vip-input, .vip-select,
.vip-btn, .vip-table, .vip-card-header-title {
    font-family: 'AR Techni', sans-serif !important;
}

/* ══════════════════════════════════════
   GLOBAL BACKGROUND
══════════════════════════════════════ */
html, body {
    background: #060d1a !important;
    color: #e0f7f4 !important;
    min-height: 100vh;
}

.main-content, .content-wrapper, main, .wrapper {
    background: #060d1a !important;
}

nav, .navbar, header {
    background: #060d1a !important;
    border-bottom: 1px solid rgba(0,230,200,0.12) !important;
}
nav .navbar-brand, nav .nav-link, .navbar-brand, header a {
    color: #00e6c8 !important;
}
.sidebar, .side-nav, aside {
    background: #040b16 !important;
    border-right: 1px solid rgba(0,200,180,0.1) !important;
}
footer, .footer {
    background: #060d1a !important;
    border-top: 1px solid rgba(0,230,200,0.12) !important;
    color: rgba(255,255,255,0.4) !important;
}
footer strong, .footer strong { color: #00e6c8 !important; }

/* ══════════════════════════════════════
   GENERATE CARD
══════════════════════════════════════ */
.vip-gen-card {
    background: rgba(8, 18, 35, 0.97);
    border: 1px solid rgba(0,200,180,0.22);
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 0 40px rgba(0,0,0,0.7), 0 0 80px rgba(0,150,140,0.04);
    margin-bottom: 24px;
    position: relative;
}

.vip-gen-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #00e6c8, #00aaff, transparent);
    z-index: 1;
}

.vip-card-header {
    background: linear-gradient(135deg, rgba(0,150,140,0.28) 0%, rgba(0,100,200,0.18) 100%);
    border-bottom: 1px solid rgba(0,200,180,0.18);
    padding: 14px 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.vip-card-header-title {
    color: #ffffff;
    font-size: 1rem;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
}

.vip-header-dot {
    width: 8px; height: 8px;
    background: #00e6c8;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 6px #00e6c8;
    animation: vip-pulse 2s ease-in-out infinite;
}

@keyframes vip-pulse {
    0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 6px #00e6c8; }
    50%       { opacity: 0.45; transform: scale(0.75); box-shadow: 0 0 2px #00e6c8; }
}

.vip-card-body { padding: 22px 20px 20px; }

/* ══════════════════════════════════════
   FORM ELEMENTS
══════════════════════════════════════ */
.vip-form-group { margin-bottom: 18px; }

.vip-label {
    color: rgba(0,220,200,0.9);
    font-size: 0.7rem;
    letter-spacing: 1.8px;
    margin-bottom: 9px;
    display: block;
    text-transform: uppercase;
}

.vip-input-wrap {
    display: flex;
    align-items: stretch;
    margin-bottom: 4px;
}

.vip-input-prefix {
    background: rgba(0,200,180,0.1);
    border: 1px solid rgba(0,200,180,0.22);
    border-right: none;
    border-radius: 10px 0 0 10px;
    padding: 0 14px;
    color: #00e6c8;
    font-size: 1.05rem;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 44px;
}

.vip-input {
    width: 100%;
    background: rgba(255,255,255,0.035);
    border: 1px solid rgba(0,200,180,0.18);
    border-radius: 10px;
    padding: 12px 16px;
    font-size: 0.93rem;
    color: #d8f5f0;
    outline: none;
    transition: border-color .22s, box-shadow .22s, background .22s;
    -webkit-appearance: none;
}

.vip-input-wrap .vip-input {
    border-radius: 0 10px 10px 0;
}

.vip-input::placeholder { color: rgba(255,255,255,0.18); }

.vip-input:focus {
    border-color: rgba(0,200,180,0.52);
    background: rgba(0,200,180,0.045);
    box-shadow: 0 0 0 3px rgba(0,200,180,0.11);
}

/* Select */
.vip-select,
select.vip-select {
    width: 100%;
    background: rgba(255,255,255,0.035)
        url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2300e6c8' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")
        no-repeat right 14px center;
    border: 1px solid rgba(0,200,180,0.18);
    border-radius: 10px;
    padding: 12px 40px 12px 16px;
    font-size: 0.93rem;
    color: #d8f5f0;
    outline: none;
    appearance: none;
    -webkit-appearance: none;
    cursor: pointer;
    transition: border-color .22s, box-shadow .22s;
}

.vip-select:focus, select.vip-select:focus {
    border-color: rgba(0,200,180,0.52);
    background-color: rgba(0,200,180,0.045);
    box-shadow: 0 0 0 3px rgba(0,200,180,0.11);
}

.vip-select option, select.vip-select option {
    background: #0d1f38;
    color: #d8f5f0;
}

.vip-error {
    color: #ff6b6b;
    font-size: 0.76rem;
    margin-top: 5px;
    display: block;
    letter-spacing: 0.5px;
}

/* Button */
.vip-btn {
    background: linear-gradient(135deg, #00c8b4 0%, #00aaff 100%);
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 12px 28px;
    font-size: 0.88rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    cursor: pointer;
    transition: opacity .2s, transform .15s, box-shadow .2s;
    box-shadow: 0 4px 18px rgba(0,200,180,0.22);
}

.vip-btn:hover {
    opacity: 0.87;
    transform: translateY(-1px);
    box-shadow: 0 6px 24px rgba(0,200,180,0.32);
}
.vip-btn:active { transform: translateY(0); }

/* ══════════════════════════════════════
   HISTORY CARD
══════════════════════════════════════ */
.vip-history-card {
    background: rgba(8, 18, 35, 0.97);
    border: 1px solid rgba(0,200,180,0.18);
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 0 40px rgba(0,0,0,0.55);
    position: relative;
}

.vip-history-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #00c8b4, #7bfc77, transparent);
}

.vip-history-header {
    background: linear-gradient(135deg, rgba(0,180,100,0.18) 0%, rgba(0,100,200,0.13) 100%);
    border-bottom: 1px solid rgba(0,200,180,0.14);
    padding: 13px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.vip-history-title {
    color: #fff;
    font-size: 0.92rem;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
}

.vip-total-badge {
    background: rgba(0,200,180,0.13);
    border: 1px solid rgba(0,200,180,0.28);
    border-radius: 20px;
    padding: 3px 13px;
    color: #00e6c8;
    font-size: 0.72rem;
    letter-spacing: 1.2px;
}

.vip-table-wrap {
    overflow-x: auto;
    padding: 14px 16px 16px;
}

.vip-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.8rem;
}

.vip-table thead tr {
    background: rgba(0,200,180,0.07);
    border-bottom: 1px solid rgba(0,200,180,0.18);
}

.vip-table thead th {
    color: #00e6c8;
    font-weight: 700;
    letter-spacing: 1.2px;
    padding: 10px 12px;
    text-align: center;
    font-size: 0.68rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.vip-table tbody tr {
    border-bottom: 1px solid rgba(255,255,255,0.035);
    transition: background .14s;
}

.vip-table tbody tr:hover {
    background: rgba(0,200,180,0.045);
}

.vip-table tbody td {
    color: rgba(220,245,242,0.72);
    padding: 10px 12px;
    text-align: center;
    white-space: nowrap;
}

.vip-table tbody td:nth-child(2) {
    color: #00e6c8;
    font-weight: 700;
    font-size: 0.83rem;
    letter-spacing: 0.5px;
}

.vip-table tbody td:nth-child(4) {
    color: #7bfc77;
    font-weight: 700;
}
</style>

<div class="row g-3 mt-1">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-4 mb-3">
        <div class="vip-gen-card">
            <div class="vip-card-header">
                <span class="vip-header-dot"></span>
                <span class="vip-card-header-title">إنشاء <?= $title ?></span>
            </div>
            <div class="vip-card-body">
                <?= form_open() ?>

                <div class="vip-form-group">
                    <label class="vip-label" for="set_saldo">يمكنك التعيين برصيد متعدد</label>
                    <div class="vip-input-wrap">
                        <span class="vip-input-prefix">
                            <i class="bi bi-currency-dollar"></i>
                        </span>
                        <input type="number"
                               class="vip-input"
                               name="set_saldo"
                               id="set_saldo"
                               minlength="1"
                               maxlength="11"
                               value="50000">
                    </div>
                    <?php if ($validation->hasError('set_saldo')) : ?>
                        <small class="vip-error"><?= $validation->getError('set_saldo') ?></small>
                    <?php endif; ?>
                </div>

                <div class="vip-form-group">
                    <label class="vip-label" for="accExpire">انتهاء صلاحية الحساب</label>
                    <?= form_dropdown([
                        'class' => 'vip-select',
                        'name'  => 'accExpire',
                        'id'    => 'accExpire'
                    ], $accExpire, old('accExpire') ?: '') ?>
                    <?php if ($validation->hasError('accExpire')) : ?>
                        <small class="vip-error"><?= $validation->getError('accExpire') ?></small>
                    <?php endif; ?>
                </div>

                <div class="vip-form-group">
                    <label class="vip-label" for="accLevel">مستوى الحساب</label>
                    <?= form_dropdown([
                        'class' => 'vip-select',
                        'name'  => 'accLevel',
                        'id'    => 'accLevel'
                    ], $accLevel, old('accLevel') ?: '') ?>
                    <?php if ($validation->hasError('accLevel')) : ?>
                        <small class="vip-error"><?= $validation->getError('accLevel') ?></small>
                    <?php endif; ?>
                </div>

                <div class="vip-form-group mb-0">
                    <button type="submit" class="vip-btn">&#43;&nbsp; إنشاء الكود</button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <?php if ($code) : ?>
        <div class="vip-history-card">
            <div class="vip-history-header">
                <span class="vip-history-title">&#128203; سجل الإنشاء</span>
                <span class="vip-total-badge">الإجمالي: <?= $total_code ?></span>
            </div>
            <div class="vip-table-wrap">
                <table class="vip-table">
                    <thead>
                        <tr>
                            <th>المعرف (ID)</th>
                            <th>الإحالة</th>
                            <th>المشفر</th>
                            <th>الرصيد</th>
                            <th>المستوى</th>
                            <th>الانتهاء</th>
                            <th>مستخدم من قبل</th>
                            <th>تم الإنشاء بواسطة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($code as $c) : ?>
                            <tr>
                                <td><?= $c->id_reff ?></td>
                                <td><?= $c->Referral ?></td>
                                <td><?= substr($c->code, 1, 15) ?></td>
                                <td>₹<?= $c->set_saldo ?></td>
                                <td><?= $c->level ?></td>
                                <td><?= $c->acc_expiration ?></td>
                                <td><?= $c->used_by ?></td>
                                <td><?= $c->created_by ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<br><br>
<?= $this->endSection() ?>
