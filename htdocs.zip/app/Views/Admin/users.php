<?php
function color($value) {
    if ($value == 1) {
        return "#00e6c8"; // Owner → cyan
    } else {
        return "#ff6b6b"; // Others → red
    }
}
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
/* ══════════════════════════════════════
   AR TECHNI FONT
══════════════════════════════════════ */
@font-face {
    font-family: 'AR Techni';
    src: url('<?= base_url('assets/fonts/AR_Techni.ttf') ?>') format('truetype');
    font-weight: normal;
    font-style: normal;
}

html, body,
*, *::before, *::after,
input, select, textarea, button,
label, th, td, span, div, p, a {
    font-family: 'AR Techni', sans-serif !important;
}

/* ══════════════════════════════════════
   GLOBAL BG
══════════════════════════════════════ */
html, body {
    background: #060d1a !important;
    color: #e0f7f4 !important;
    min-height: 100vh;
}
.main-content, .content-wrapper, main, .wrapper {
    background: #060d1a !important;
}
nav, .navbar, header {
    background: #060d1a !important;
    border-bottom: 1px solid rgba(0,230,200,0.12) !important;
}
nav .navbar-brand, nav .nav-link, .navbar-brand, header a {
    color: #00e6c8 !important;
}
.sidebar, .side-nav, aside {
    background: #040b16 !important;
    border-right: 1px solid rgba(0,200,180,0.1) !important;
}
footer, .footer {
    background: #060d1a !important;
    border-top: 1px solid rgba(0,230,200,0.12) !important;
    color: rgba(255,255,255,0.4) !important;
}
footer strong, .footer strong { color: #00e6c8 !important; }

/* ══════════════════════════════════════
   INFO ALERT
══════════════════════════════════════ */
.vip-info-alert {
    background: rgba(0,200,180,0.07);
    border: 1px solid rgba(0,200,180,0.2);
    border-left: 3px solid #00e6c8;
    border-radius: 10px;
    padding: 13px 18px;
    color: rgba(220,245,242,0.75);
    font-size: 0.83rem;
    letter-spacing: 0.3px;
    margin-bottom: 18px;
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.vip-info-alert strong {
    color: #00e6c8;
    font-weight: 700;
    letter-spacing: 1px;
}

.vip-info-icon {
    font-size: 1rem;
    margin-top: 1px;
    flex-shrink: 0;
}

/* ══════════════════════════════════════
   MANAGE USERS CARD
══════════════════════════════════════ */
.vip-users-card {
    background: rgba(8, 18, 35, 0.97);
    border: 1px solid rgba(0,200,180,0.22);
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 0 40px rgba(0,0,0,0.7), 0 0 80px rgba(0,150,140,0.04);
    position: relative;
}

.vip-users-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #00e6c8, #00aaff, transparent);
    z-index: 1;
}

/* Card Header */
.vip-users-header {
    background: linear-gradient(135deg, rgba(0,150,140,0.28) 0%, rgba(0,100,200,0.18) 100%);
    border-bottom: 1px solid rgba(0,200,180,0.18);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.vip-users-header-dot {
    width: 8px; height: 8px;
    background: #00e6c8;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 6px #00e6c8;
    animation: vip-pulse 2s ease-in-out infinite;
}

@keyframes vip-pulse {
    0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 6px #00e6c8; }
    50%       { opacity: 0.4; transform: scale(0.75); box-shadow: 0 0 2px #00e6c8; }
}

.vip-users-title {
    color: #ffffff;
    font-size: 1.05rem;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

/* Card Body */
.vip-users-body {
    padding: 18px 16px;
}

/* ══════════════════════════════════════
   TABLE
══════════════════════════════════════ */
.vip-table-wrap {
    overflow-x: auto;
}

.vip-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.8rem;
}

.vip-table thead tr {
    background: rgba(0,200,180,0.07);
    border-bottom: 1px solid rgba(0,200,180,0.2);
}

.vip-table thead th {
    color: #00e6c8;
    font-weight: 700;
    letter-spacing: 1.2px;
    padding: 11px 13px;
    text-align: center;
    font-size: 0.68rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.vip-table tbody tr {
    border-bottom: 1px solid rgba(255,255,255,0.035);
    transition: background .14s;
}

.vip-table tbody tr:hover {
    background: rgba(0,200,180,0.045);
}

.vip-table tbody td {
    color: rgba(220,245,242,0.72);
    padding: 11px 13px;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
}

/* Username column */
.vip-table tbody td:nth-child(2) {
    color: #ffffff;
    font-weight: 600;
}

/* Action button */
.vip-action-btn {
    background: rgba(0,200,180,0.1);
    border: 1px solid rgba(0,200,180,0.3);
    border-radius: 7px;
    color: #00e6c8;
    padding: 5px 10px;
    font-size: 0.82rem;
    cursor: pointer;
    transition: background .18s, box-shadow .18s, transform .12s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.vip-action-btn:hover {
    background: rgba(0,200,180,0.22);
    box-shadow: 0 0 10px rgba(0,200,180,0.2);
    color: #00e6c8;
    transform: translateY(-1px);
    text-decoration: none;
}

/* Level badge */
.vip-badge {
    display: inline-block;
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.vip-badge-owner {
    background: rgba(0,200,180,0.14);
    border: 1px solid rgba(0,200,180,0.35);
    color: #00e6c8;
}

.vip-badge-admin {
    background: rgba(100,100,255,0.14);
    border: 1px solid rgba(100,100,255,0.35);
    color: #7b7fff;
}

.vip-badge-reseller {
    background: rgba(255,160,50,0.14);
    border: 1px solid rgba(255,160,50,0.35);
    color: #ffaa44;
}

/* Status badge */
.vip-status-active {
    background: rgba(100,220,100,0.12);
    border: 1px solid rgba(100,220,100,0.3);
    color: #7bfc77;
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1px;
    display: inline-block;
}

.vip-status-banned {
    background: rgba(255,80,80,0.12);
    border: 1px solid rgba(255,80,80,0.3);
    color: #ff6b6b;
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1px;
    display: inline-block;
}

.vip-status-expired {
    background: rgba(180,180,180,0.1);
    border: 1px solid rgba(180,180,180,0.25);
    color: rgba(200,200,200,0.6);
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 1px;
    display: inline-block;
}

/* DataTables overrides */
.dataTables_wrapper .dataTables_length select,
.dataTables_wrapper .dataTables_filter input {
    background: rgba(255,255,255,0.04) !important;
    border: 1px solid rgba(0,200,180,0.2) !important;
    border-radius: 8px !important;
    color: #d8f5f0 !important;
    padding: 5px 10px !important;
    outline: none !important;
}

.dataTables_wrapper .dataTables_filter input:focus {
    border-color: rgba(0,200,180,0.5) !important;
    box-shadow: 0 0 0 2px rgba(0,200,180,0.1) !important;
}

.dataTables_wrapper .dataTables_info,
.dataTables_wrapper .dataTables_length label,
.dataTables_wrapper .dataTables_filter label {
    color: rgba(200,240,235,0.55) !important;
    font-size: 0.78rem !important;
}

.dataTables_wrapper .paginate_button {
    background: rgba(0,200,180,0.08) !important;
    border: 1px solid rgba(0,200,180,0.2) !important;
    border-radius: 7px !important;
    color: #00e6c8 !important;
    margin: 2px !important;
}

.dataTables_wrapper .paginate_button:hover {
    background: rgba(0,200,180,0.2) !important;
    color: #fff !important;
}

.dataTables_wrapper .paginate_button.current {
    background: linear-gradient(135deg, #00c8b4, #00aaff) !important;
    color: #fff !important;
    border-color: transparent !important;
}
</style>

<div class="row">
    <div class="col-lg-12">

        <div class="vip-info-alert">
            <span class="vip-info-icon">&#8505;</span>
            <div>
                <strong>معلومات :</strong> يمكنك البحث عن مستخدم معين بواسطة (اسم المستخدم، الاسم الكامل، الرصيد، أو الرابط).
            </div>
        </div>

        <div class="vip-users-card">
            <div class="vip-users-header">
                <span class="vip-users-header-dot"></span>
                <span class="vip-users-title">&#128100; إدارة المستخدمين</span>
            </div>
            <div class="vip-users-body">
                <?php if ($user_list) : ?>
                <div class="vip-table-wrap">
                    <table id="usersTable" class="vip-table">
                        <thead>
                            <tr>
                                <th>المعرف (ID)</th>
                                <th>اسم المستخدم</th>
                                <th>الاسم الكامل</th>
                                <th>المستوى</th>
                                <th>الرصيد</th>
                                <th>الحالة</th>
                                <th>الرابط</th>
                                <th>تاريخ الانتهاء</th>
                                <th>الإجراء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($user_list as $u) : ?>
                            <tr>
                                <td><?= $u->id_users ?></td>
                                <td><?= $u->username ?></td>
                                <td><?= $u->fullname ?></td>
                                <td>
                                    <?php if ($u->level == 1) : ?>
                                        <span class="vip-badge vip-badge-owner">المالك</span>
                                    <?php elseif ($u->level == 2) : ?>
                                        <span class="vip-badge vip-badge-admin">مدير</span>
                                    <?php else : ?>
                                        <span class="vip-badge vip-badge-reseller">موزع</span>
                                    <?php endif; ?>
                                </td>
                                <td style="color:#7bfc77; font-weight:600;">
                                    <?php if ($u->level == 1) : ?>
                                        <span style="color:rgba(200,240,235,0.4);">—</span>
                                    <?php else : ?>
                                        <?= $u->saldo ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($u->status == 1) : ?>
                                        <span class="vip-status-active">نشط</span>
                                    <?php elseif ($u->status == 2) : ?>
                                        <span class="vip-status-banned">محظور</span>
                                    <?php else : ?>
                                        <span class="vip-status-expired">منتهي</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $u->uplink ?></td>
                                <td><?= $u->expiration_date ?></td>
                                <td>
                                    <a href="user/<?= $u->id_users ?>" class="vip-action-btn">
                                        <i class="bi bi-pencil-square"></i> تعديل
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<br><br><br>
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
$(document).ready(function () {
    $('#usersTable').DataTable({
        language: {
            search: "&#128269;",
            searchPlaceholder: "البحث عن مستخدمين...",
        },
        pageLength: 10,
        order: [[0, 'asc']],
    });
});
</script>
<?= $this->endSection() ?>
