<?php
include('mail.php');
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
/* ══════════════════════════════════════
   AR TECHNI FONT
══════════════════════════════════════ */
@font-face {
    font-family: 'AR Techni';
    src: url('<?= base_url('assets/fonts/AR_Techni.ttf') ?>') format('truetype');
    font-weight: normal;
    font-style: normal;
}

html, body,
*, *::before, *::after,
input, select, textarea, button,
label, th, td, span, div, p, a {
    font-family: 'AR Techni', sans-serif !important;
}

/* ══════════════════════════════════════
   GLOBAL BG
══════════════════════════════════════ */
html, body {
    background: #060d1a !important;
    color: #e0f7f4 !important;
    min-height: 100vh;
}
.main-content, .content-wrapper, main, .wrapper {
    background: #060d1a !important;
}
nav, .navbar, header {
    background: #060d1a !important;
    border-bottom: 1px solid rgba(0,230,200,0.12) !important;
}
nav .navbar-brand, nav .nav-link, .navbar-brand, header a {
    color: #00e6c8 !important;
}
.sidebar, .side-nav, aside {
    background: #040b16 !important;
    border-right: 1px solid rgba(0,200,180,0.1) !important;
}
footer, .footer {
    background: #060d1a !important;
    border-top: 1px solid rgba(0,230,200,0.12) !important;
    color: rgba(255,255,255,0.4) !important;
}
footer strong, .footer strong { color: #00e6c8 !important; }

/* ══════════════════════════════════════
   EDIT CARD
══════════════════════════════════════ */
.vip-edit-card {
    background: rgba(8, 18, 35, 0.97);
    border: 1px solid rgba(0,200,180,0.22);
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 0 40px rgba(0,0,0,0.7), 0 0 80px rgba(0,150,140,0.04);
    position: relative;
    margin-bottom: 30px;
}

.vip-edit-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #00e6c8, #00aaff, transparent);
    z-index: 1;
}

/* Card Header */
.vip-edit-header {
    background: linear-gradient(135deg, rgba(0,150,140,0.28) 0%, rgba(0,100,200,0.18) 100%);
    border-bottom: 1px solid rgba(0,200,180,0.18);
    padding: 14px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}

.vip-edit-header-left {
    display: flex;
    align-items: center;
    gap: 10px;
}

.vip-header-dot {
    width: 8px; height: 8px;
    background: #00e6c8;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 6px #00e6c8;
    animation: vip-pulse 2s ease-in-out infinite;
}

@keyframes vip-pulse {
    0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 6px #00e6c8; }
    50%       { opacity: 0.4; transform: scale(0.75); box-shadow: 0 0 2px #00e6c8; }
}

.vip-edit-title {
    color: #ffffff;
    font-size: 0.95rem;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
}

.vip-edit-username {
    color: #00e6c8;
    font-weight: 700;
}

/* Back button */
.vip-back-btn {
    background: rgba(0,200,180,0.1);
    border: 1px solid rgba(0,200,180,0.28);
    border-radius: 8px;
    color: #00e6c8;
    padding: 6px 14px;
    font-size: 0.78rem;
    letter-spacing: 1px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: background .18s, box-shadow .18s;
    flex-shrink: 0;
}

.vip-back-btn:hover {
    background: rgba(0,200,180,0.2);
    box-shadow: 0 0 10px rgba(0,200,180,0.18);
    color: #00e6c8;
    text-decoration: none;
}

/* Card Body */
.vip-edit-body {
    padding: 24px 22px 20px;
}

/* ══════════════════════════════════════
   FORM ELEMENTS
══════════════════════════════════════ */
.vip-form-group {
    margin-bottom: 18px;
}

.vip-label {
    color: rgba(0,220,200,0.88);
    font-size: 0.7rem;
    letter-spacing: 1.8px;
    margin-bottom: 8px;
    display: block;
    text-transform: uppercase;
}

.vip-input {
    width: 100%;
    background: rgba(255,255,255,0.035);
    border: 1px solid rgba(0,200,180,0.18);
    border-radius: 10px;
    padding: 12px 16px;
    font-size: 0.93rem;
    color: #d8f5f0;
    outline: none;
    transition: border-color .22s, box-shadow .22s, background .22s;
    -webkit-appearance: none;
}

.vip-input::placeholder { color: rgba(255,255,255,0.18); }

.vip-input:focus {
    border-color: rgba(0,200,180,0.52);
    background: rgba(0,200,180,0.045);
    box-shadow: 0 0 0 3px rgba(0,200,180,0.11);
}

/* Select */
.vip-select,
select.vip-select {
    width: 100%;
    background: rgba(255,255,255,0.035)
        url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2300e6c8' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")
        no-repeat right 14px center;
    border: 1px solid rgba(0,200,180,0.18);
    border-radius: 10px;
    padding: 12px 40px 12px 16px;
    font-size: 0.93rem;
    color: #d8f5f0;
    outline: none;
    appearance: none;
    -webkit-appearance: none;
    cursor: pointer;
    transition: border-color .22s, box-shadow .22s;
}

.vip-select:focus, select.vip-select:focus {
    border-color: rgba(0,200,180,0.52);
    background-color: rgba(0,200,180,0.045);
    box-shadow: 0 0 0 3px rgba(0,200,180,0.11);
}

.vip-select option, select.vip-select option {
    background: #0d1f38;
    color: #d8f5f0;
}

/* Error */
.vip-error {
    color: #ff6b6b;
    font-size: 0.76rem;
    margin-top: 5px;
    display: block;
    letter-spacing: 0.5px;
}

/* Divider */
.vip-section-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0,200,180,0.15), transparent);
    margin: 20px 0;
}

/* Submit Button */
.vip-submit-btn {
    background: linear-gradient(135deg, #00c8b4 0%, #00aaff 100%);
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 13px 32px;
    font-size: 0.88rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    cursor: pointer;
    transition: opacity .2s, transform .15s, box-shadow .2s;
    box-shadow: 0 4px 18px rgba(0,200,180,0.22);
    width: 100%;
}

.vip-submit-btn:hover {
    opacity: 0.87;
    transform: translateY(-1px);
    box-shadow: 0 6px 24px rgba(0,200,180,0.32);
}
.vip-submit-btn:active { transform: translateY(0); }
</style>

<div class="row justify-content-center pt-3">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-3">
        <div class="vip-edit-card">

            <div class="vip-edit-header">
                <div class="vip-edit-header-left">
                    <span class="vip-header-dot"></span>
                    <span class="vip-edit-title">
                        معلومات الحساب &middot; <span class="vip-edit-username"><?= getName($target) ?></span>
                    </span>
                </div>
                <a href="<?= site_url('admin/manage-users') ?>" class="vip-back-btn">
                    <i class="bi bi-arrow-left"></i> رجوع
                </a>
            </div>

            <div class="vip-edit-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= $target->id_users ?>">

                <div class="row g-3">

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="username">&#128100; اسم المستخدم</label>
                            <input type="text"
                                   name="username" id="username"
                                   class="vip-input"
                                   value="<?= old('username') ?: $target->username ?>">
                            <?php if ($validation->hasError('username')) : ?>
                                <small class="vip-error"><?= $validation->getError('username') ?></small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="fullname">&#128203; الاسم الكامل</label>
                            <input type="text"
                                   name="fullname" id="fullname"
                                   class="vip-input"
                                   value="<?= old('fullname') ?: $target->fullname ?>">
                            <?php if ($validation->hasError('fullname')) : ?>
                                <small class="vip-error"><?= $validation->getError('fullname') ?></small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="level">&#127775; الأدوار</label>
                            <?php $sel_level = ['' => '— اختر الدور —', '1' => 'مالك', '2' => 'مدير', '3' => 'موزع']; ?>
                            <?= form_dropdown([
                                'class' => 'vip-select',
                                'name'  => 'level',
                                'id'    => 'level'
                            ], $sel_level, $target->level) ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="status">&#128994; الحالة</label>
                            <?php $sel_status = ['' => '— اختر الحالة —', '2' => 'محظور/موقوف', '1' => 'نشط', '3' => 'منتهي الصلاحية']; ?>
                            <?= form_dropdown([
                                'class' => 'vip-select',
                                'name'  => 'status',
                                'id'    => 'status'
                            ], $sel_status, $target->status) ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="saldo">&#128176; الرصيد</label>
                            <input type="number"
                                   name="saldo" id="saldo"
                                   class="vip-input"
                                   value="<?= old('saldo') ?: $target->saldo ?>">
                            <?php if ($validation->hasError('saldo')) : ?>
                                <small class="vip-error"><?= $validation->getError('saldo') ?></small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="uplink">&#128279; الرابط/المُحيل</label>
                            <input type="text"
                                   name="uplink" id="uplink"
                                   class="vip-input"
                                   value="<?= old('uplink') ?: $target->uplink ?>">
                            <?php if ($validation->hasError('uplink')) : ?>
                                <small class="vip-error"><?= $validation->getError('uplink') ?></small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="vip-form-group">
                            <label class="vip-label" for="expiration">&#128197; تاريخ الانتهاء</label>
                            <input type="text"
                                   name="expiration" id="expiration"
                                   class="vip-input"
                                   value="<?= old('expiration') ?: $target->expiration_date ?>">
                            <?php if ($validation->hasError('expiration')) : ?>
                                <small class="vip-error"><?= $validation->getError('expiration') ?></small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-12 mt-2">
                        <div class="vip-section-divider"></div>
                        <button type="submit" class="vip-submit-btn">
                            &#10003;&nbsp; تحديث معلومات الحساب
                        </button>
                    </div>

                </div>
                <?= form_close() ?>
            </div>

        </div>
    </div>
</div>

<?= $this->endSection() ?>
