<!doctype html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <!-- Title -->
    <title><?= BASE_NAME ?> - <?= isset($title) ? $title : 'لوحة التحكم' ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom Font -->
    <style>
        @font-face {
            font-family: 'AR';
            src: url('/assets/fonts/ar_regular.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
        }
    </style>

    <!-- Custom CSS -->
    <?= $this->renderSection('css') ?>
    <?= link_tag('assets/css/natacode.css') ?>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Particles.js -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

    <style>
        /* ===== BASE ===== */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'AR', 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #080c14;
            color: #fff;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* ===== ANIMATED DARK BACKGROUND ===== */
        .animated-bg {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: linear-gradient(-45deg, #060a12, #0a1020, #080e1a, #050810);
            background-size: 400% 400%;
            animation: bgShift 20s ease infinite;
            z-index: -2;
        }

        @keyframes bgShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        /* ===== PARTICLES ===== */
        #particles-js {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: -1;
        }

        /* ===== MAIN CONTAINER ===== */
        .main-container {
            background: rgba(255, 255, 255, 0.02);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 16px;
        }

        /* ===== FOOTER ===== */
        footer {
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255,255,255,0.05) !important;
            color: rgba(255,255,255,0.3);
            font-family: 'AR', sans-serif;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        /* ===== HOVER GLOW ===== */
        .hover-glow:hover {
            text-shadow: 0 0 10px rgba(0,229,255,0.8);
        }

        /* ===== SCROLLBAR ===== */
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(0,229,255,0.2); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(0,229,255,0.4); }
    </style>
</head>

<body>

    <!-- Background Layers -->
    <div class="animated-bg"></div>
    <div id="particles-js"></div>

    <!-- Header Include -->
    <?= $this->include('Layout/Header') ?>

    <!-- Main Content -->
    <main>
        <div class="container main-container">
            <?= $this->renderSection('content') ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="text-center py-3 border-top mt-5">
        <div class="container">
            <small>Copyright &copy; <?= date('Y') ?> &bull; <?= BASE_NAME ?> &bull; All Rights Reserved</small>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.5/sweetalert2.all.min.js"></script>

    <!-- Custom JS -->
    <?= script_tag('assets/js/natacode.js') ?>
    <?= $this->renderSection('js') ?>

    <!-- Particles Config -->
    <script>
        particlesJS('particles-js', {
            particles: {
                number: { value: 60, density: { enable: true, value_area: 800 } },
                color: { value: "#00e5ff" },
                shape: { type: "circle" },
                opacity: { value: 0.2 },
                size: { value: 2.5, random: true },
                line_linked: {
                    enable: true,
                    distance: 140,
                    color: "#00e5ff",
                    opacity: 0.12,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: "none",
                    out_mode: "out"
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "repulse" },
                    onclick: { enable: true, mode: "push" },
                    resize: true
                }
            },
            retina_detect: true
        });
    </script>

</body>
</html>
