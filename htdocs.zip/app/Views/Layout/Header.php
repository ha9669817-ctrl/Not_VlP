<header>
    <nav class="vip-navbar navbar navbar-expand-lg shadow-sm">
        <div class="container px-3">

            <!-- Brand / VIP PANEL -->
            <a class="navbar-brand vip-brand" href="<?= site_url() ?>">
                <span class="brand-icon">
                    <i class="bi bi-key-fill"></i>
                    <span class="brand-dot"></span>
                </span>
                <span class="brand-text"><?= BASE_NAME ?></span>
            </a>

            <!-- Toggler -->
            <button class="vip-toggler navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false">
                <i class="bi bi-list"></i>
            </button>

            <!-- Navigation -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <?php if (session()->has('userid')) : ?>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="vip-nav-link nav-link" href="<?= site_url('keys') ?>">
                                <i class="bi bi-key me-1"></i>المفاتيح
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="vip-nav-link nav-link" href="<?= site_url('keys/generate') ?>">
                                <i class="bi bi-plus-circle me-1"></i>إنشاء مفتاح
                            </a>
                        </li>
                    </ul>

                    <!-- User Dropdown -->
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="vip-nav-link nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-person-circle me-1"></i><?= getName($user) ?>
                            </a>
                            <ul class="vip-dropdown dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li>
                                    <a class="dropdown-item vip-drop-item" href="<?= site_url('settings') ?>">
                                        <i class="bi bi-gear me-2"></i>الإعدادات
                                    </a>
                                </li>

                                <li><hr class="vip-divider dropdown-divider"></li>

                                <?php if (($user->level == 1) || ($user->level == 2)) : ?>
                                    <li>
                                        <a class="dropdown-item vip-drop-item" href="<?= site_url('Server') ?>">
                                            <i class="bi bi-controller me-2"></i>نظام الأونلاين
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item vip-drop-item" href="<?= site_url('admin/manage-users') ?>">
                                            <i class="bi bi-person-check me-2"></i>إدارة المستخدمين
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item vip-drop-item" href="<?= site_url('admin/create-referral') ?>">
                                            <i class="bi bi-person-plus me-2"></i>إنشاء إحالة
                                        </a>
                                    </li>
                                    <li><hr class="vip-divider dropdown-divider"></li>
                                <?php endif; ?>

                                <li>
                                    <a class="dropdown-item vip-drop-item vip-logout" href="<?= site_url('logout') ?>">
                                        <i class="bi bi-box-arrow-left me-2"></i>تسجيل الخروج
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                <?php else : ?>
                    <!-- Not logged in: show login/register buttons -->
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="vip-nav-link nav-link" href="<?= site_url('login') ?>">
                                <i class="bi bi-box-arrow-in-right me-1"></i>تسجيل الدخول
                            </a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>

        </div>
    </nav>
</header>

<!-- Header Styles -->
<style>
    /* ===== NAVBAR ===== */
    .vip-navbar {
        background: rgba(8, 12, 20, 0.85) !important;
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid rgba(0,229,255,0.12);
        padding: 10px 0;
    }

    /* ===== BRAND ===== */
    .vip-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
    }

    .brand-icon {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        background: rgba(0,229,255,0.1);
        border: 1px solid rgba(0,229,255,0.3);
        border-radius: 8px;
        color: #00e5ff;
        font-size: 16px;
    }

    .brand-dot {
        position: absolute;
        bottom: -2px;
        right: -2px;
        width: 8px;
        height: 8px;
        background: #00e5ff;
        border-radius: 50%;
        border: 2px solid #080c14;
        box-shadow: 0 0 6px #00e5ff;
    }

    .brand-text {
        font-family: 'AR', sans-serif;
        font-size: 1.15rem;
        font-weight: 700;
        color: #00e5ff;
        letter-spacing: 2px;
        text-transform: uppercase;
    }

    /* ===== NAV LINKS ===== */
    .vip-nav-link {
        font-family: 'AR', sans-serif !important;
        color: rgba(255,255,255,0.6) !important;
        font-size: 0.88rem;
        font-weight: 500;
        letter-spacing: 0.5px;
        padding: 6px 14px !important;
        border-radius: 8px;
        transition: all 0.2s ease;
    }

    .vip-nav-link:hover,
    .vip-nav-link:focus {
        color: #00e5ff !important;
        background: rgba(0,229,255,0.08);
    }

    /* ===== TOGGLER ===== */
    .vip-toggler {
        background: rgba(0,229,255,0.08);
        border: 1px solid rgba(0,229,255,0.2);
        color: #00e5ff;
        font-size: 1.2rem;
        padding: 6px 10px;
        border-radius: 8px;
        transition: all 0.2s;
    }

    .vip-toggler:hover {
        background: rgba(0,229,255,0.15);
    }

    .vip-toggler:focus {
        box-shadow: 0 0 0 3px rgba(0,229,255,0.15);
        outline: none;
    }

    /* ===== DROPDOWN ===== */
    .vip-dropdown {
        background: rgba(10, 14, 24, 0.95);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(0,229,255,0.15);
        border-radius: 14px;
        box-shadow:
            0 20px 50px rgba(0,0,0,0.6),
            0 0 0 1px rgba(0,229,255,0.05);
        min-width: 220px;
        padding: 8px;
        margin-top: 8px !important;
    }

    .vip-drop-item {
        font-family: 'AR', sans-serif !important;
        color: rgba(255,255,255,0.7) !important;
        font-size: 0.88rem;
        border-radius: 8px;
        padding: 9px 14px !important;
        transition: all 0.2s;
        letter-spacing: 0.3px;
    }

    .vip-drop-item:hover {
        background: rgba(0,229,255,0.08) !important;
        color: #00e5ff !important;
    }

    .vip-logout {
        color: rgba(255, 90, 90, 0.8) !important;
    }

    .vip-logout:hover {
        background: rgba(255,80,80,0.08) !important;
        color: #ff6b6b !important;
    }

    .vip-divider {
        border-color: rgba(255,255,255,0.06) !important;
        margin: 4px 0 !important;
    }
</style>
