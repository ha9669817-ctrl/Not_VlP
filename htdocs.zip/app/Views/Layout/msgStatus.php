<?php if (session()->getFlashdata('msgDanger')) : ?>
    <div class="vunnik-msg vunnik-msg-danger" role="alert">
        <span class="vunnik-msg-icon">⚠️</span>
        <span class="vunnik-msg-text"><?= session()->getFlashdata('msgDanger') ?></span>
        <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
    </div>

<?php elseif (session()->getFlashdata('msgSuccess')) : ?>
    <div class="vunnik-msg vunnik-msg-success" role="alert">
        <span class="vunnik-msg-icon">✅</span>
        <span class="vunnik-msg-text"><?= session()->getFlashdata('msgSuccess') ?></span>
        <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
    </div>

<?php elseif (session()->getFlashdata('msgWarning')) : ?>
    <div class="vunnik-msg vunnik-msg-warning" role="alert">
        <span class="vunnik-msg-icon">🔔</span>
        <span class="vunnik-msg-text"><?= session()->getFlashdata('msgWarning') ?></span>
        <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
    </div>

<?php else : ?>
    <?php if (session()->has('userid')) : ?>
        <?php if (isset($messages)) : ?>
            <div class="vunnik-msg vunnik-msg-info" role="alert">
                <span class="vunnik-msg-icon">📘</span>
                <span class="vunnik-msg-text"><?= $messages[0] ?></span>
                <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
            </div>
        <?php else : ?>
            <div class="vunnik-msg vunnik-msg-welcome" role="alert">
                <span class="vunnik-msg-icon">📘</span>
                <span class="vunnik-msg-text">أهلاً بك يا <?= getName($user) ?>! 🌟<br><small>نتمنى لك وقتاً ممتعاً في جلستك.</small></span>
                <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
            </div>
        <?php endif; ?>
    <?php else : ?>
        <div class="vunnik-msg vunnik-msg-welcome" role="alert">
            <span class="vunnik-msg-icon">📘</span>
            <span class="vunnik-msg-text">أهلاً بك يا زائر! 🌟<br><small>يرجى تسجيل الدخول للمتابعة.</small></span>
            <button class="vunnik-msg-close" onclick="this.parentElement.style.display='none'">×</button>
        </div>
    <?php endif; ?>
<?php endif; ?>

<style>
.vunnik-msg {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    border-radius: 10px;
    padding: 14px 16px;
    margin-bottom: 16px;
    position: relative;
    font-size: 0.875rem;
    line-height: 1.5;
}

/* Welcome / Info — white card with blue left border (Speedy style) */
.vunnik-msg-welcome,
.vunnik-msg-info {
    background: #ffffff;
    border-left: 4px solid #1565c0;
    color: #1565c0;
}
.vunnik-msg-welcome .vunnik-msg-text,
.vunnik-msg-info .vunnik-msg-text {
    color: #1565c0;
}

/* Success — dark green */
.vunnik-msg-success {
    background: rgba(63,185,80,0.1);
    border-left: 4px solid #3fb950;
    color: #3fb950;
}
.vunnik-msg-success .vunnik-msg-text { color: #3fb950; }

/* Danger — dark red */
.vunnik-msg-danger {
    background: rgba(248,81,73,0.1);
    border-left: 4px solid #f85149;
    color: #f85149;
}
.vunnik-msg-danger .vunnik-msg-text { color: #f85149; }

/* Warning — dark yellow */
.vunnik-msg-warning {
    background: rgba(227,179,65,0.1);
    border-left: 4px solid #e3b341;
    color: #e3b341;
}
.vunnik-msg-warning .vunnik-msg-text { color: #e3b341; }

.vunnik-msg-icon {
    font-size: 1.1rem;
    flex-shrink: 0;
    margin-top: 1px;
}

.vunnik-msg-text {
    flex: 1;
}
.vunnik-msg-text small {
    opacity: 0.75;
    font-size: 0.8rem;
}

.vunnik-msg-close {
    background: none;
    border: none;
    font-size: 1.1rem;
    cursor: pointer;
    color: inherit;
    opacity: 0.5;
    padding: 0;
    line-height: 1;
    flex-shrink: 0;
    transition: opacity 0.2s;
}
.vunnik-msg-close:hover { opacity: 1; }
</style>
