<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    /* ===== VIP PANEL - DARK TEAL STYLE ===== */
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700&family=Rajdhani:wght@400;500;600&display=swap');

    @font-face {
        font-family: 'AR Techni';
        src: url('/assets/fonts/AR_Techni.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
        font-display: swap;
    }

    :root {
        --teal:        #00e5c4;
        --teal-dim:    #00b39a;
        --teal-glow:   rgba(0, 229, 196, 0.18);
        --teal-soft:   rgba(0, 229, 196, 0.08);
        --card-bg:     #0e1525;
        --card-border: rgba(0, 229, 196, 0.22);
        --header-bg:   linear-gradient(135deg, #0d1f2d 0%, #0a2a2a 100%);
        --row-hover:   rgba(0, 229, 196, 0.06);
        --text-main:   #e0f7f4;
        --text-muted:  #7a9ea8;
        --danger:      #ff4d6d;
        --warning:     #ffd166;
        --info:        #00b4d8;
        --success:     #06d6a0;
    }

    .glass-card {
        border-radius: 16px;
        background: var(--card-bg);
        border: 1px solid var(--card-border);
        box-shadow: 0 0 0 1px rgba(0,229,196,0.07), 0 8px 40px rgba(0,0,0,0.55), inset 0 1px 0 rgba(0,229,196,0.1);
        color: var(--text-main);
        overflow: hidden;
        font-family: 'Rajdhani', sans-serif;
    }

    .card-header.glass-header {
        background: var(--header-bg);
        border-bottom: 1px solid var(--card-border);
        padding: 14px 20px;
        position: relative;
    }

    .card-header.glass-header::after {
        content: '';
        position: absolute;
        bottom: 0; left: 0; right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--teal), transparent);
        opacity: 0.6;
    }

    .header-title {
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 14px;
        font-weight: normal;
        letter-spacing: 2px;
        color: var(--teal);
        text-transform: uppercase;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .secure-dot {
        display: inline-block;
        width: 7px; height: 7px;
        border-radius: 50%;
        background: var(--teal);
        box-shadow: 0 0 8px var(--teal);
        animation: pulse-dot 2s infinite;
        flex-shrink: 0;
    }

    @keyframes pulse-dot {
        0%, 100% { opacity: 1; }
        50%       { opacity: 0.3; }
    }

    #blur-out {
        background: var(--teal-soft);
        border: 1px solid var(--card-border);
        color: var(--teal);
        border-radius: 8px;
        padding: 3px 10px;
        font-size: 13px;
        transition: all 0.25s;
    }
    #blur-out:hover {
        background: var(--teal-glow);
        box-shadow: 0 0 10px var(--teal-glow);
        color: #fff;
    }

    .dropdown-menu {
        background: #0d1a28;
        border: 1px solid var(--card-border);
        border-radius: 12px;
        padding: 8px 0;
        box-shadow: 0 10px 40px rgba(0,0,0,0.6), 0 0 20px rgba(0,229,196,0.08);
        min-width: 220px;
    }

    .dropdown-menu .card-header {
        background: transparent;
        border-bottom: 1px solid var(--card-border);
        color: var(--teal);
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 10px;
        letter-spacing: 1.5px;
        padding: 8px 16px;
    }

    .dropdown-item {
        color: var(--text-main);
        font-family: 'Rajdhani', sans-serif;
        font-size: 14px;
        font-weight: 500;
        letter-spacing: 0.5px;
        padding: 10px 18px;
        transition: all 0.2s;
        border-left: 2px solid transparent;
    }
    .dropdown-item:hover {
        background: var(--teal-soft);
        color: var(--teal);
        border-left-color: var(--teal);
    }
    .dropdown-item i { width: 20px; text-align: center; margin-right: 8px; }

    .nav-link.dropdown-toggle {
        color: var(--teal) !important;
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        font-size: 14px;
        letter-spacing: 1px;
        background: var(--teal-soft);
        border: 1px solid var(--card-border);
        border-radius: 8px;
        padding: 5px 14px;
        transition: all 0.25s;
    }
    .nav-link.dropdown-toggle:hover {
        background: var(--teal-glow);
        box-shadow: 0 0 12px var(--teal-glow);
    }

    .table {
        color: var(--text-main);
        font-family: 'Rajdhani', sans-serif;
        font-size: 14px;
    }

    .table thead tr th {
        background: linear-gradient(135deg, #0a2020, #0d2a2a);
        border-color: var(--card-border);
        color: var(--teal);
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 10px;
        font-weight: normal;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        padding: 14px 12px;
        white-space: nowrap;
    }

    .table td {
        background: transparent;
        border-color: rgba(0, 229, 196, 0.07);
        padding: 12px;
        vertical-align: middle;
        transition: background 0.2s;
    }

    .table tbody tr:hover td { background: var(--row-hover); }
    .table tbody tr:nth-child(even) td { background: rgba(0,229,196,0.025); }
    .table tbody tr:nth-child(even):hover td { background: var(--row-hover); }

    .key-sensi {
        filter: blur(5px);
        transition: filter 0.35s ease;
    }

    .badge-expired {
        background: rgba(255,77,109,0.15);
        color: var(--danger);
        border: 1px solid rgba(255,77,109,0.3);
        border-radius: 6px;
        padding: 3px 10px;
        font-size: 12px;
        font-family: 'Rajdhani', sans-serif;
        font-weight: 600;
        letter-spacing: 0.5px;
    }

    .text-success { color: var(--success) !important; }
    .text-danger  { color: var(--danger)  !important; }

    .btn-outline-danger, .btn-outline-warning, .btn-outline-info {
        border-radius: 8px; font-size: 13px; padding: 4px 10px;
        transition: all 0.25s; border-width: 1px;
    }
    .btn-outline-danger  { color: var(--danger)  !important; border-color: rgba(255,77,109,0.4);   background: rgba(255,77,109,0.07);  }
    .btn-outline-warning { color: var(--warning)  !important; border-color: rgba(255,209,102,0.4); background: rgba(255,209,102,0.07); }
    .btn-outline-info    { color: var(--info)     !important; border-color: rgba(0,180,216,0.4);   background: rgba(0,180,216,0.07);   }

    .btn-outline-danger:hover  { background: rgba(255,77,109,0.2);  border-color: var(--danger);  box-shadow: 0 0 10px rgba(255,77,109,0.25);  color: #fff !important; }
    .btn-outline-warning:hover { background: rgba(255,209,102,0.2); border-color: var(--warning); box-shadow: 0 0 10px rgba(255,209,102,0.2); color: #fff !important; }
    .btn-outline-info:hover    { background: rgba(0,180,216,0.2);   border-color: var(--info);    box-shadow: 0 0 10px rgba(0,180,216,0.25);   color: #fff !important; }

    .btn-secondary {
        background: var(--teal-soft);
        border: 1px solid var(--card-border);
        color: var(--text-muted);
        border-radius: 8px; font-size: 13px; transition: all 0.25s;
    }
    .btn-secondary:hover { background: var(--teal-glow); color: var(--teal); }

    /* DataTables */
    .dataTables_wrapper .dataTables_filter label,
    .dataTables_wrapper .dataTables_length label,
    .dataTables_wrapper .dataTables_info {
        color: var(--text-muted); font-family: 'Rajdhani', sans-serif; font-size: 13px;
    }

    .dataTables_wrapper .dataTables_filter input,
    .dataTables_wrapper .dataTables_length select {
        background: rgba(0,229,196,0.06);
        color: var(--text-main);
        border: 1px solid var(--card-border);
        border-radius: 8px; padding: 5px 10px; outline: none;
        font-family: 'Rajdhani', sans-serif; transition: border-color 0.2s;
    }
    .dataTables_wrapper .dataTables_filter input:focus,
    .dataTables_wrapper .dataTables_length select:focus {
        border-color: var(--teal);
        box-shadow: 0 0 0 3px rgba(0,229,196,0.1);
    }
    .dataTables_wrapper .dataTables_filter input::placeholder { color: var(--text-muted); }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: var(--text-muted) !important; border: 1px solid transparent !important;
        border-radius: 8px !important; font-family: 'Rajdhani', sans-serif;
        font-size: 13px; transition: all 0.2s; margin: 1px;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        background: var(--teal-soft) !important; border-color: var(--card-border) !important; color: var(--teal) !important;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        background: linear-gradient(135deg, #004d3f, var(--teal-dim)) !important;
        border-color: var(--teal) !important; color: #fff !important;
        box-shadow: 0 0 12px rgba(0,229,196,0.3);
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
        color: #2a3a4a !important; cursor: not-allowed;
    }

    .dataTables_processing {
        background: rgba(10,15,26,0.9) !important; color: var(--teal) !important;
        border: 1px solid var(--card-border) !important; border-radius: 10px !important;
        font-family: 'AR Techni', 'Orbitron', sans-serif !important; font-size: 11px !important; letter-spacing: 1px;
    }

    /* SweetAlert2 */
    .swal2-popup {
        background: #0e1525 !important; color: var(--text-main) !important;
        border-radius: 16px !important; border: 1px solid var(--card-border) !important;
        font-family: 'Rajdhani', sans-serif !important;
        box-shadow: 0 20px 60px rgba(0,0,0,0.7), 0 0 30px rgba(0,229,196,0.08) !important;
    }
    .swal2-title {
        color: var(--teal) !important; font-family: 'AR Techni', 'Orbitron', sans-serif !important;
        font-size: 18px !important; letter-spacing: 1.5px;
    }
    .swal2-html-container { color: var(--text-muted) !important; }
    .swal2-confirm {
        background: linear-gradient(135deg, #005c4b, var(--teal-dim)) !important;
        border: none !important; border-radius: 8px !important;
        font-family: 'Rajdhani', sans-serif !important; font-weight: 600 !important;
        letter-spacing: 1px; box-shadow: 0 0 15px rgba(0,229,196,0.2) !important;
    }
    .swal2-cancel {
        background: rgba(255,77,109,0.15) !important; border: 1px solid rgba(255,77,109,0.35) !important;
        color: var(--danger) !important; border-radius: 8px !important;
        font-family: 'Rajdhani', sans-serif !important; font-weight: 600 !important; letter-spacing: 1px;
    }
    .swal2-icon.swal2-warning { border-color: var(--warning) !important; color: var(--warning) !important; }

    /* Empty state */
    .empty-state {
        text-align: center; padding: 60px 20px;
        color: var(--text-muted); font-family: 'Rajdhani', sans-serif;
        font-size: 15px; letter-spacing: 1px;
    }
    .empty-state i { font-size: 40px; color: rgba(0,229,196,0.2); display: block; margin-bottom: 12px; }

    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: #0a0f1a; }
    ::-webkit-scrollbar-thumb { background: var(--teal-dim); border-radius: 10px; }
</style>

<div class="row justify-content-center">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
        <div class="col-lg-12">
            <div class="card glass-card">
                <div class="card-header glass-header">
                    <div class="row align-items-center">
                        <div class="col pt-1 d-flex align-items-center gap-2">
                            <span class="header-title">
                                <span class="secure-dot"></span>
                                المفاتيح المسجلة
                            </span>
                            <button class="btn btn-secondary btn-sm ms-1" id="blur-out"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="حماية العين">
                                <i class="bi bi-eye-slash"></i>
                            </button>
                        </div>
                        <div class="col text-end">
                            <ul class="navbar-nav justify-content-end mb-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-file-arrow-down-fill me-1"></i> فتح القائمة
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <div class="card-header">⚡ إجراءات سريعة</div>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('keys/generate') ?>">
                                                <i class="bi bi-key-fill" style="color: var(--success)"></i>
                                                إِنْشَاءُ مِفْتَاحٍ
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('keys/deleteExp') ?>">
                                                <i class="bi bi-eraser-fill" style="color: var(--warning)"></i>
                                                حَذْفُ الْمَفَاتِيحِ الْمُنْتَهِيَةِ
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('keys/deleteUnused') ?>">
                                                <i class="bi bi-box-seam" style="color: var(--danger)"></i>
                                                حَذْفُ الْمَفَاتِيحِ غَيْرِ الْمُسْتَخْدَمَةِ
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <?php if ($keylist) : ?>
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اللعبة</th>
                                        <th>مفاتيح المستخدم</th>
                                        <th>الأجهزة</th>
                                        <th>المدة</th>
                                        <th>تاريخ الانتهاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    <?php else : ?>
                        <div class="empty-state">
                            <i class="bi bi-key"></i>
                            لا توجد مفاتيح مسجلة بعد.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>

<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [
                { data: 'id', name: 'id_keys' },
                { data: 'game' },
                {
                    data: 'user_key',
                    render: function(data, type, row) {
                        var cls = (row.status == 'Active') ? 'text-success' : 'text-danger';
                        return `<span class="${cls} keyBlur key-sensi fw-bold">${row.user_key || '&mdash;'}</span>`;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row) {
                        return `<span id="devMax-${row.user_key}">${row.devices || 0}/${row.max_devices}</span>`;
                    }
                },
                {
                    data: 'duration',
                    render: function(data, type, row) { return row.duration; }
                },
                {
                    data: 'expired', name: 'expired_date',
                    render: function(data, type, row) {
                        return row.expired
                            ? `<span class="badge-expired">${row.expired}</span>`
                            : `<span style="color:#2a4a4a;font-size:12px;">— لم يبدأ —</span>`;
                    }
                },
                {
                    data: null,
                    render: function(data, type, row) {
                        var btnReset  = `<button class="btn btn-outline-danger btn-sm" onclick="resetUserKey('${row.user_key}')" title="إعادة تعيين"><i class="bi bi-bootstrap-reboot"></i></button>`;
                        var btnDelete = `<button class="btn btn-outline-warning btn-sm" onclick="resetUserKey1('${row.user_key}')" title="حذف المفتاح"><i class="bi bi-trash-fill"></i></button>`;
                        var btnEdit   = `<a href="${window.location.origin}/index.php/keys/edit/${row.id}" class="btn btn-outline-info btn-sm" title="تعديل المفتاح"><i class="bi bi-person-fill"></i></a>`;
                        return `<div class="d-flex gap-1 justify-content-center">${btnReset}${btnDelete}${btnEdit}</div>`;
                    }
                }
            ]
        });

        $("#blur-out").click(function() {
            if ($(".keyBlur").hasClass("key-sensi")) {
                $(".keyBlur").removeClass("key-sensi");
                $(this).html('<i class="bi bi-eye"></i>');
            } else {
                $(".keyBlur").addClass("key-sensi");
                $(this).html('<i class="bi bi-eye-slash"></i>');
            }
        });
    });

    function resetUserKey1(keys) {
        Swal.fire({
            title: 'حَذْفُ الْمِفْتَاحِ؟',
            text: "لن تتمكن من التراجع عن هذا!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'نعم، حذف',
            cancelButtonText: 'إلغاء',
            reverseButtons: true
        }).then((result) => {
            if (!result.isConfirmed) return;
            
            Swal.fire({ title: 'يرجى الانتظار...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });

            $.ajax({
                url: "<?= site_url('keys/resetAll') ?>",
                type: 'GET',
                data: { userkey: keys, reset: 1 },
                dataType: 'json',
                success: function(data) {
                    Swal.close();
                    if (data.registered) {
                        if (data.reset) {
                            $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                            Swal.fire({ title: 'تم الحذف!', text: 'تم حذف المفتاح.', icon: 'success' });
                            $('#datatable').DataTable().ajax.reload();
                        } else {
                            Swal.fire({ title: 'فشل!', text: data.devices_total ? "لا يوجد صلاحية لهذا المستخدم." : "تم إعادة تعيين المفتاح مسبقاً.", icon: data.devices_total ? 'error' : 'warning' });
                        }
                    } else {
                        Swal.fire({ title: 'فشل!', text: "المفتاح لم يعد موجوداً.", icon: 'error' });
                    }
                },
                error: function() {
                    Swal.close();
                    Swal.fire({ title: 'تمت العملية!', text: 'تم حذف المفتاح بنجاح.', icon: 'success' });
                    $('#datatable').DataTable().ajax.reload();
                }
            });
        });
    }

    function resetUserKey(keys) {
        Swal.fire({
            title: 'إعادة تعيين المفتاح؟',
            text: "سيتم إعادة تعيين عدد الأجهزة إلى 0.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'نعم، إعادة تعيين',
            cancelButtonText: 'إلغاء',
            reverseButtons: true
        }).then((result) => {
            if (!result.isConfirmed) return;

            Swal.fire({ title: 'يرجى الانتظار...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });

            $.ajax({
                url: "<?= site_url('keys/reset') ?>",
                type: 'GET',
                data: { userkey: keys, reset: 1 },
                dataType: 'json',
                success: function(data) {
                    Swal.close();
                    if (data.registered) {
                        if (data.reset) {
                            $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                            Swal.fire({ title: 'تمت العملية!', text: 'تم إعادة تعيين مفتاح الجهاز.', icon: 'success' });
                            $('#datatable').DataTable().ajax.reload();
                        } else {
                            Swal.fire({ title: 'فشل!', text: data.devices_total ? "لا يوجد صلاحية لهذا المستخدم." : "تمت إعادة التعيين مسبقاً.", icon: data.devices_total ? 'error' : 'warning' });
                        }
                    } else {
                        Swal.fire({ title: 'فشل!', text: "المفتاح لم يعد موجوداً.", icon: 'error' });
                    }
                },
                error: function() {
                    Swal.close();
                    Swal.fire({ title: 'تمت العملية!', text: 'تمت إعادة تعيين المفتاح بنجاح.', icon: 'success' });
                    $('#datatable').DataTable().ajax.reload();
                }
            });
        });
    }
</script>

<?= $this->endSection() ?>
