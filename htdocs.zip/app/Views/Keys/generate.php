<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
    /* ===== VIP PANEL - DARK TEAL STYLE ===== */
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700&family=Rajdhani:wght@400;500;600&display=swap');

    @font-face {
        font-family: 'AR Techni';
        src: url('/assets/fonts/AR_Techni.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
        font-display: swap;
    }

    :root {
        --teal:        #00e5c4;
        --teal-dim:    #00b39a;
        --teal-glow:   rgba(0, 229, 196, 0.18);
        --teal-soft:   rgba(0, 229, 196, 0.08);
        --card-bg:     #0e1525;
        --card-border: rgba(0, 229, 196, 0.22);
        --header-bg:   linear-gradient(135deg, #0d1f2d 0%, #0a2a2a 100%);
        --input-bg:    rgba(0, 229, 196, 0.05);
        --text-main:   #e0f7f4;
        --text-muted:  #7a9ea8;
        --text-label:  #a0c8c0;
        --danger:      #ff4d6d;
        --warning:     #ffd166;
        --success:     #06d6a0;
    }

    /* ---- Alert success (key result) ---- */
    .alert-success {
        background: rgba(6, 214, 160, 0.1) !important;
        border: 1px solid rgba(6, 214, 160, 0.35) !important;
        border-radius: 12px !important;
        color: var(--text-main) !important;
        font-family: 'Rajdhani', sans-serif;
        font-size: 15px;
        padding: 16px 20px;
    }

    .alert-success strong {
        color: var(--teal);
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 13px;
        letter-spacing: 1.5px;
    }

    /* Key copy row */
    .key-copy-row {
        background: rgba(0, 229, 196, 0.06);
        border: 1px solid var(--card-border);
        border-radius: 10px;
        padding: 10px 16px;
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 12px;
        color: var(--teal);
        letter-spacing: 1px;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 16px;
        word-break: break-all;
    }

    .key-copy-row #copybtn {
        cursor: pointer;
        color: var(--text-muted);
        font-size: 16px;
        transition: color 0.2s;
        flex-shrink: 0;
    }
    .key-copy-row #copybtn:hover { color: var(--teal); }

    /* ---- Main Card ---- */
    .vip-card {
        border-radius: 16px;
        background: var(--card-bg);
        border: 1px solid var(--card-border);
        box-shadow:
            0 0 0 1px rgba(0,229,196,0.06),
            0 10px 50px rgba(0,0,0,0.6),
            inset 0 1px 0 rgba(0,229,196,0.08);
        overflow: hidden;
        font-family: 'Rajdhani', sans-serif;
    }

    /* ---- Card Header ---- */
    .vip-header {
        background: var(--header-bg);
        border-bottom: 1px solid var(--card-border);
        padding: 16px 22px;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .vip-header::after {
        content: '';
        position: absolute;
        bottom: 0; left: 0; right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--teal), transparent);
        opacity: 0.55;
    }

    .vip-header .title {
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 15px;
        font-weight: normal;
        letter-spacing: 2.5px;
        color: var(--teal);
        text-transform: uppercase;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .secure-dot {
        display: inline-block;
        width: 7px; height: 7px;
        border-radius: 50%;
        background: var(--teal);
        box-shadow: 0 0 8px var(--teal);
        animation: pulse-dot 2s infinite;
        flex-shrink: 0;
    }

    @keyframes pulse-dot {
        0%, 100% { opacity: 1; }
        50%       { opacity: 0.3; }
    }

    .vip-header .btn-back {
        background: var(--teal-soft);
        border: 1px solid var(--card-border);
        color: var(--teal);
        border-radius: 8px;
        padding: 5px 12px;
        font-size: 14px;
        transition: all 0.25s;
        text-decoration: none;
    }
    .vip-header .btn-back:hover {
        background: var(--teal-glow);
        box-shadow: 0 0 12px var(--teal-glow);
        color: #fff;
    }

    /* ---- Card Body ---- */
    .vip-body {
        padding: 28px 24px;
        background: linear-gradient(180deg, #0e1828 0%, #0a1520 100%);
    }

    /* ---- Form Labels ---- */
    .form-label {
        color: var(--text-label);
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 11px;
        font-weight: normal;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        margin-bottom: 8px;
        display: block;
    }

    /* ---- Inputs & Selects ---- */
    .form-control,
    .form-select {
        background: var(--input-bg) !important;
        border: 1px solid var(--card-border) !important;
        border-radius: 10px !important;
        color: var(--text-main) !important;
        font-family: 'Rajdhani', sans-serif !important;
        font-size: 15px !important;
        padding: 11px 14px !important;
        transition: border-color 0.25s, box-shadow 0.25s;
        outline: none !important;
    }

    .form-control::placeholder { color: var(--text-muted) !important; }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--teal) !important;
        box-shadow: 0 0 0 3px rgba(0,229,196,0.12) !important;
        background: rgba(0,229,196,0.08) !important;
    }

    .form-control[readonly] {
        background: rgba(0,0,0,0.2) !important;
        color: var(--teal) !important;
        border-color: rgba(0,229,196,0.15) !important;
        font-family: 'AR Techni', 'Orbitron', sans-serif !important;
        font-size: 13px !important;
        letter-spacing: 1px;
    }

    /* Select arrow color */
    .form-select {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%2300e5c4' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3E%3C/svg%3E") !important;
        background-repeat: no-repeat !important;
        background-position: right 12px center !important;
        background-size: 14px !important;
        padding-right: 36px !important;
    }

    /* ---- Checkbox (Custom Key) ---- */
    .custom-check-wrap {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        background: var(--teal-soft);
        border: 1px solid var(--card-border);
        border-radius: 10px;
        cursor: pointer;
        transition: background 0.2s;
        margin-bottom: 20px;
    }
    .custom-check-wrap:hover { background: var(--teal-glow); }

    .custom-check-wrap label {
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 11px;
        letter-spacing: 1.5px;
        color: var(--teal);
        cursor: pointer;
        margin: 0;
    }

    .form-check-input {
        width: 18px !important;
        height: 18px !important;
        background-color: rgba(0,229,196,0.1) !important;
        border: 1px solid var(--card-border) !important;
        border-radius: 5px !important;
        cursor: pointer;
        transition: all 0.2s;
        flex-shrink: 0;
    }
    .form-check-input:checked {
        background-color: var(--teal) !important;
        border-color: var(--teal) !important;
        box-shadow: 0 0 8px rgba(0,229,196,0.4) !important;
    }

    /* ---- Divider ---- */
    .vip-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--card-border), transparent);
        margin: 22px 0;
    }

    /* ---- Generate Button ---- */
    .btn-generate {
        width: 100%;
        padding: 14px;
        background: linear-gradient(135deg, #004d3f 0%, var(--teal-dim) 100%);
        border: 1px solid var(--teal);
        border-radius: 12px;
        color: #fff;
        font-family: 'AR Techni', 'Orbitron', sans-serif;
        font-size: 14px;
        font-weight: normal;
        letter-spacing: 4px;
        text-transform: uppercase;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        cursor: pointer;
    }

    .btn-generate::before {
        content: '';
        position: absolute;
        top: 0; left: -100%;
        width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
        transition: left 0.5s ease;
    }

    .btn-generate:hover {
        box-shadow: 0 0 25px rgba(0,229,196,0.4), 0 0 50px rgba(0,229,196,0.15);
        transform: translateY(-1px);
        color: #fff;
    }

    .btn-generate:hover::before { left: 100%; }
    .btn-generate:active { transform: translateY(0); }

    /* ---- Form group spacing ---- */
    .vip-group { margin-bottom: 20px; }

    /* ---- Text danger ---- */
    .text-danger {
        color: var(--danger) !important;
        font-family: 'Rajdhani', sans-serif;
        font-size: 12px;
        margin-top: 5px;
        display: block;
    }

    /* ---- Hidden textarea ---- */
    textarea#mytext {
        width: 0; height: 0;
        padding: 0; border: 0;
        border-radius: 0;
        background-color: transparent;
        font-size: 16px;
        resize: none;
        position: absolute;
        opacity: 0;
    }

    /* ---- Scrollbar ---- */
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: #0a0f1a; }
    ::-webkit-scrollbar-thumb { background: var(--teal-dim); border-radius: 10px; }
</style>

<br>
<div class="row justify-content-center">
    <div class="col-lg-6">

        <?= $this->include('Layout/msgStatus') ?>

        <?php if (session()->getFlashdata('user_key')) : ?>

            <div class="alert alert-success" role="alert">
                <strong>✅ تم إنشاء المفتاح بنجاح</strong><br><br>
                اللعبة &nbsp;&nbsp;: <?= session()->getFlashdata('game') ?> / <?= session()->getFlashdata('duration') ?> ساعة<br>
                الأجهزة : <?= session()->getFlashdata('max_devices') ?> جهاز<br>
                <small style="color: var(--text-muted)"><i>يبدأ احتساب الوقت عند تسجيل الدخول لأول مرة.</i></small>
            </div>

            <div class="key-copy-row">
                <span style="flex:1"><?= session()->getFlashdata('user_key') ?></span>
                <i class="bi bi-clipboard" id="copybtn" onclick="copyText()" title="نسخ المفتاح"></i>
            </div>

            <textarea id="mytext"><?= session()->getFlashdata('user_key') ?></textarea>

            <script>
                function copyText() {
                    var mytext = document.getElementById("mytext");
                    mytext.select();
                    document.execCommand("copy");
                    document.getElementById("copybtn").className = "bi bi-clipboard-check";
                    setTimeout(() => {
                        document.getElementById("copybtn").className = "bi bi-clipboard";
                    }, 2000);
                }
            </script>

        <?php endif; ?>

        <div class="vip-card">

            <div class="vip-header">
                <span class="title">
                    <span class="secure-dot"></span>
                    إنشاء ترخيص
                </span>
                <a class="btn-back" href="<?= site_url('keys') ?>">
                    <i class="bi bi-people"></i>
                </a>
            </div>

            <div class="vip-body">
                <?= form_open() ?>

                <div class="row">
                    <div class="form-group col-lg-6 vip-group">
                        <label for="game" class="form-label">اللعبة</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                        <?php if ($validation->hasError('game')) : ?>
                            <small class="text-danger"><?= $validation->getError('game') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-lg-6 vip-group">
                        <label for="max_devices" class="form-label">أقصى عدد للأجهزة</label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control"
                            placeholder="1" value="<?= old('max_devices') ?: 1 ?>">
                        <?php if ($validation->hasError('max_devices')) : ?>
                            <small class="text-danger"><?= $validation->getError('max_devices') ?></small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="vip-group">
                    <label for="duration" class="form-label">المدة (بالساعات)</label>
                    <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    <?php if ($validation->hasError('duration')) : ?>
                        <small class="text-danger"><?= $validation->getError('duration') ?></small>
                    <?php endif; ?>
                </div>

                <div class="vip-divider"></div>

                <div class="custom-check-wrap" onclick="document.getElementById('check').click()">
                    <input class="form-check-input" type="checkbox"
                        value="" name="check" onchange="fupi(this)" id="check" onclick="event.stopPropagation()">
                    <label class="form-label mb-0" for="check">مفتاح مخصص</label>
                </div>

                <div class="vip-group" id="cusWrap" style="display:none">
                    <label for="custom" id="cuslabel" class="form-label">أدخل المفتاح الخاص بك</label>
                    <input type="text" minlength="4" maxlength="16" name="cuslicense"
                        class="form-control" id="custom" placeholder="أدخل المفتاح هنا...">
                </div>

                <div class="vip-group" id="bulkWrap">
                    <label for="hulala" id="labula" class="form-label">إنشاء كمية</label>
                    <select class="form-select" id="hulala" name="loopcount">
                        <option value="5">1 مفتاح</option>
                        <option value="1">5 مفاتيح</option>
                        <option value="2">10 مفاتيح</option>
                        <option value="3">25 مفتاحاً</option>
                        <option value="3">50 مفتاحاً</option>
                        <option value="4">100 مفتاح</option>
                    </select>
                </div>

                <input type="text" id="textinput" name="custominput" value="auto" hidden>

                <div class="vip-divider"></div>

                <div class="vip-group">
                    <label for="estimation" class="form-label">السعر التقديري</label>
                    <input type="text" id="estimation" class="form-control"
                        placeholder="سيظهر إجمالي الطلب هنا" readonly>
                </div>

                <div class="form-group text-center mt-2">
                    <button type="submit" class="btn-generate">
                        <i class="bi bi-key-fill me-2"></i> إنشاء
                    </button>
                </div>

                <?= form_close() ?>
            </div></div></div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        getPrice(price);

        $("#max_devices, #duration, #game").change(function() {
            getPrice(price);
        });

        function getPrice(price) {
            var device = $("#max_devices").val();
            var durate = $("#duration").val();
            var gprice = price[durate];
            if (!isNaN(gprice)) {
                $("#estimation").val(device * gprice);
            } else {
                $("#estimation").val('خطأ في حساب السعر');
            }
        }
    });

    function fupi(obj) {
        if ($(obj).is(":checked")) {
            document.getElementById("cusWrap").style.display = "block";
            document.getElementById("bulkWrap").style.display = "none";
            document.getElementById("textinput").value = "custom";
        } else {
            document.getElementById("cusWrap").style.display = "none";
            document.getElementById("bulkWrap").style.display = "block";
            document.getElementById("textinput").value = "auto";
        }
    }
</script>
<?= $this->endSection() ?>
