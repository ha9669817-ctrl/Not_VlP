<?php
include('conn.php');
include('mail.php');

$sql1 = "select * from onoff where id=1";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1);

$sql2 = "select * from _ftext where id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2);

$sql3 = "SELECT * FROM Feature WHERE id=1";
$result3 = mysqli_query($conn, $sql3);
$ModFeatureStatus = mysqli_fetch_assoc($result3);
?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
@font-face {
    font-family: 'AR Techni';
    src: url('<?= base_url('assets/fonts/AR_Techni.ttf') ?>') format('truetype');
}
* { font-family: 'AR Techni', sans-serif !important; }

body { background: #0d1117 !important; color: #e6edf3; }
.animated-bg { background: #0d1117 !important; }
nav, .navbar, header { background: #161b22 !important; border-bottom: 1px solid #30363d !important; }
nav .navbar-brand, nav .nav-link, .navbar-brand { color: #00d4aa !important; }
footer, .footer {
    background: #161b22 !important;
    border-top: 1px solid #30363d !important;
    color: #8b949e !important;
}

/* ── Layout ── */
.srv-wrap {
    padding: 24px 16px;
    max-width: 900px;
    margin: 0 auto;
}

/* ── Card ── */
.vip-card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 14px;
    overflow: hidden;
    margin-bottom: 24px;
}
.vip-card-header {
    background: #1c2128;
    border-bottom: 1px solid #30363d;
    padding: 14px 20px;
    font-size: 0.95rem;
    font-weight: 600;
    color: #e6edf3;
    display: flex;
    align-items: center;
    gap: 8px;
}
.vip-card-header i { color: #00d4aa; }
.vip-card-body { padding: 20px; }

/* ── Current status line ── */
.srv-status-line {
    font-size: 0.82rem;
    color: #8b949e;
    margin-bottom: 16px;
    line-height: 1.6;
}
.srv-status-line span { color: #00d4aa; }

/* ── Toggle switch ── */
.vip-toggle-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid #21262d;
}
.vip-toggle-row:last-of-type { border-bottom: none; }
.vip-toggle-label {
    font-size: 0.875rem;
    color: #c9d1d9;
}

.vip-switch {
    position: relative;
    width: 46px;
    height: 24px;
    flex-shrink: 0;
}
.vip-switch input { opacity: 0; width: 0; height: 0; }
.vip-slider {
    position: absolute;
    cursor: pointer;
    inset: 0;
    background: #30363d;
    border-radius: 24px;
    transition: background 0.2s;
}
.vip-slider:before {
    content: '';
    position: absolute;
    width: 18px; height: 18px;
    left: 3px; top: 3px;
    background: #8b949e;
    border-radius: 50%;
    transition: transform 0.2s, background 0.2s;
}
.vip-switch input:checked + .vip-slider { background: rgba(0,212,170,0.25); }
.vip-switch input:checked + .vip-slider:before {
    transform: translateX(22px);
    background: #00d4aa;
}

/* ── Textarea / Input ── */
.vip-input, .vip-textarea {
    width: 100%;
    background: #0d1117;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 12px 14px;
    color: #e6edf3;
    font-size: 0.875rem;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
    box-sizing: border-box;
    resize: vertical;
}
.vip-input:focus, .vip-textarea:focus {
    border-color: #00d4aa;
    box-shadow: 0 0 0 3px rgba(0,212,170,0.12);
}
.vip-input::placeholder, .vip-textarea::placeholder { color: #484f58; }

.vip-field { margin-bottom: 18px; }
.vip-label {
    display: block;
    font-size: 0.78rem;
    color: #8b949e;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    margin-bottom: 8px;
}

/* ── Update buttons ── */
.vip-btn {
    border: none;
    border-radius: 8px;
    padding: 10px 24px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s, transform 0.15s;
    letter-spacing: 0.5px;
}
.vip-btn:hover { opacity: 0.85; transform: translateY(-1px); }
.vip-btn-cyan   { background: rgba(0,212,170,0.15); color: #00d4aa; border: 1px solid rgba(0,212,170,0.3); }
.vip-btn-red    { background: rgba(248,81,73,0.15);  color: #f85149; border: 1px solid rgba(248,81,73,0.3); }
.vip-btn-yellow { background: rgba(227,179,65,0.15); color: #e3b341; border: 1px solid rgba(227,179,65,0.3); }
.vip-btn-green  { background: rgba(63,185,80,0.15);  color: #3fb950; border: 1px solid rgba(63,185,80,0.3); }

.text-danger-vip { color: #f85149; font-size: 0.78rem; margin-top: 4px; }

/* ── Feature grid ── */
.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.feature-item {
    background: #0d1117;
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 14px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.feature-item-name {
    font-size: 0.82rem;
    color: #c9d1d9;
}
</style>

<div class="srv-wrap">
    <div class="row">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>

        <?php if($user->level != 2) : ?>
        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header">
                    <i class="fas fa-server"></i> تعديلات السيرفر
                </div>
                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="status_form" value="1">

                    <div class="srv-status-line">
                        وضع الصيانة الحالي: <span><?= $userDetails1['status'] ?></span>
                    </div>

                    <div class="vip-toggle-row" style="border-bottom:1px solid #21262d; margin-bottom:18px; padding-bottom:16px;">
                        <span class="vip-toggle-label">وضع الصيانة</span>
                        <label class="vip-switch">
                            <input type="checkbox" name="radios" id="radio" value="on"
                                <?php if ($userDetails1['status'] == "on") echo 'checked="checked"'; ?>>
                            <span class="vip-slider"></span>
                        </label>
                    </div>

                    <div class="vip-field">
                        <label class="vip-label">رسالة عدم الاتصال</label>
                        <div class="srv-status-line" style="margin-bottom:8px;">
                            الحالي: <span><?= $userDetails1['myinput'] ?></span>
                        </div>
                        <textarea class="vip-textarea" name="myInput" id="myInput" rows="2"
                            placeholder="السيرفر قيد الصيانة"></textarea>
                    </div>

                    <?php if ($validation->hasError('modname')) : ?>
                        <div class="text-danger-vip"><?= $validation->getError('modname') ?></div>
                    <?php endif; ?>

                    <button type="submit" class="vip-btn vip-btn-cyan">تحديث</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header">
                    <i class="fas fa-sliders-h"></i> ميزات التعديل
                </div>
                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="feature_form" value="1">

                    <div class="srv-status-line">
                        ESP: <span><?= $ModFeatureStatus['ESP'] ?></span> &nbsp;
                        العناصر: <span><?= $ModFeatureStatus['Item'] ?></span> &nbsp;
                        التصويب: <span><?= $ModFeatureStatus['AIM'] ?></span> &nbsp;
                        التصويب التلقائي: <span><?= $ModFeatureStatus['SilentAim'] ?></span> &nbsp;
                        تتبع الرصاص: <span><?= $ModFeatureStatus['BulletTrack'] ?></span> &nbsp;
                        الذاكرة: <span><?= $ModFeatureStatus['Memory'] ?></span> &nbsp;
                        العائمة: <span><?= $ModFeatureStatus['Floating'] ?></span> &nbsp;
                        الإعدادات: <span><?= $ModFeatureStatus['Setting'] ?></span>
                    </div>

                    <div class="feature-grid">
                        <?php
                        $features = [
                            'ESP'         => ['ESP',         'fas fa-eye'],
                            'Item'        => ['العناصر',       'fas fa-boxes'],
                            'AIM'         => ['توجيه التصويب',     'fas fa-crosshairs'],
                            'SilentAim'   => ['تصويب تلقائي',  'fas fa-user-ninja'],
                            'BulletTrack' => ['تتبع الرصاص','fas fa-dot-circle'],
                            'Memory'      => ['الذاكرة',      'fas fa-memory'],
                            'Floating'    => ['نصوص عائمة', 'fas fa-comment-dots'],
                            'Setting'     => ['الإعدادات',    'fas fa-cog'],
                        ];
                        foreach ($features as $key => [$label, $icon]) : ?>
                        <div class="feature-item">
                            <span class="feature-item-name"><i class="<?= $icon ?>" style="color:#00d4aa;margin-right:6px;"></i><?= $label ?></span>
                            <label class="vip-switch">
                                <input type="checkbox" name="<?= $key ?>" id="<?= $key ?>" value="on"
                                    <?php if ($ModFeatureStatus[$key] == "on") echo 'checked="checked"'; ?>>
                                <span class="vip-slider"></span>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <button type="submit" class="vip-btn vip-btn-red">تحديث</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header">
                    <i class="fas fa-edit"></i> تغيير اسم التعديل
                </div>
                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="modname_form" value="1">

                    <div class="srv-status-line">
                        اسم التعديل الحالي: <span><?= $row['modname'] ?></span>
                    </div>

                    <div class="vip-field">
                        <label class="vip-label">اسم التعديل الجديد</label>
                        <input type="text" name="modname" id="modname" class="vip-input"
                            placeholder="أدخل اسم التعديل الجديد" required>
                        <?php if ($validation->hasError('modname')) : ?>
                            <div class="text-danger-vip"><?= $validation->getError('modname') ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="vip-btn vip-btn-yellow">تحديث</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="vip-card">
                <div class="vip-card-header">
                    <i class="fas fa-comment-alt"></i> تغيير النص العائم
                </div>
                <div class="vip-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="_ftext" value="1">

                    <div class="srv-status-line">
                        حالة التعديل الحالية: <span><?= $userDetails2['_status'] ?></span>
                    </div>

                    <div class="vip-toggle-row" style="margin-bottom:18px; padding-bottom:16px; border-bottom:1px solid #21262d;">
                        <span class="vip-toggle-label">الوضع الآمن</span>
                        <label class="vip-switch">
                            <input type="checkbox" name="_ftextr" id="_ftextr" value="Safe"
                                <?php if ($userDetails2['_status'] == "Safe") echo 'checked="checked"'; ?>>
                            <span class="vip-slider"></span>
                        </label>
                    </div>

                    <div class="vip-field">
                        <label class="vip-label">النص العائم الحالي</label>
                        <div class="srv-status-line" style="margin-bottom:8px;">
                            الحالي: <span><?= $userDetails2['_ftext'] ?></span>
                        </div>
                        <input type="text" name="_ftext" id="_ftext" class="vip-input"
                            placeholder="أدخل ملاحظاتك هنا!" required>
                        <?php if ($validation->hasError('_ftext')) : ?>
                            <div class="text-danger-vip"><?= $validation->getError('_ftext') ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="vip-btn vip-btn-green">تحديث</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>

    </div>
</div>

<?= $this->endSection() ?>
