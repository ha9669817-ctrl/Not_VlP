<?php

$servername = "localhost";
$username = "root";       // هذا هو المستخدم الافتراضي لـ localhost
$password = "";           // غالباً لا توجد كلمة مرور افتراضياً
$dbname = "my_panel"; // تأكد أن قاعدة البيانات بهذا الاسم موجودة في phpMyAdmin

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>