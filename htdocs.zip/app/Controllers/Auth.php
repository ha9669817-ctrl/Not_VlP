<?php

namespace App\Controllers;

use App\Models\CodeModel;
use App\Models\UserModel;
use CodeIgniter\Config\Services;

class Auth extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function login()
    {
        if (session()->has('userid'))
            return redirect()->to('dashboard')->with('msgSuccess', 'تم تسجيل الدخول بنجاح!');

        if ($this->request->getPost())
            return $this->login_action();
        
        return view('Auth/login', ['title' => 'Login', 'validation' => Services::validation()]);
    }

    private function login_action()
    {
        $usernam = $this->request->getPost('username');
        $form_rules = [
            'username' => ['label' => 'username', 'rules' => 'required|is_not_unique[users.username]'],
            'password' => ['label' => 'password', 'rules' => 'required']
        ];

        if (!$this->validate($form_rules)) {
            return redirect()->route('login')->withInput()->with('msgDanger', '<strong>Failed</strong> Check inputs.');
        }

        $cekUser = $this->userModel->getUser($usernam, 'username');
        if ($cekUser) {
            // تجاوز التحقق (Bypass)
            $data = [
                'userid' => $cekUser->id_users,
                'unames' => $cekUser->username,
            ];
            session()->set($data);
            return redirect()->to('dashboard')->with('msgSuccess', 'تم تسجيل الدخول بنجاح!');
        } else {
            return redirect()->route('login')->withInput()->with('msgDanger', 'User not found.');
        }
    }

    public function register()
    {
        if (session()->has('userid'))
            return redirect()->to('dashboard');

        if ($this->request->getPost())
            return $this->register_action();
            
        return view('Auth/register', ['title' => 'Register', 'validation' => Services::validation()]);
    }

    public function register_action()
    {
        // تم تبسيط التسجيل لضمان عدم حدوث خطأ
        $userna = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        
        $data_register = [
            'email' => $this->request->getPost('email'),
            'username' => $userna,
            'fullname' => $this->request->getPost('fullname'),
            'password' => password_hash($password, PASSWORD_DEFAULT), // تشفير آمن
            'status' => 1
        ];

        if ($this->userModel->insert($data_register)) {
            return redirect()->to('login')->with('msgSuccess', 'Register Successful!');
        }
        return redirect()->route('register')->withInput()->with('msgDanger', 'Failed to register.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('login');
    }
}
