<?php
echo "السيرفر يعمل بنجاح!";
phpinfo();
?>
